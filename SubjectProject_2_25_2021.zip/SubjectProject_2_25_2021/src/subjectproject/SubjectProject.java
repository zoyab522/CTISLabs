package subjectproject;

public class SubjectProject {

    public static void main(String[] args) {
        // TODO code application logic here
        // This program is going to test our Subject class--so this is the test program or driver program
        
        // declare and instantiate a Subject object
        Subject theSubject = new Subject();
        System.out.println("The age of theSubject is " + theSubject.getAge());
        
        // let's tell theSubject that its age is 25 by using a setter
        theSubject.setAge(25);
        // now ask theSubject to report what its age is using a getter
        System.out.println("The new age of theSubject is " + theSubject.getAge());
        
        // can set the value of the age with a line like theSubject.age = 35;
        // theSubject.age = 35; gives an error that age has private access in the Subject class
        
        // instantiate a Subject object that initializes all the attributes with values we provide
        // public Subject(int age, String gender, boolean ruleFollowing, double socialValue, boolean human, int weight, 
        //    boolean pedestrian, int salary, String species) 
        Subject otherSubject = new Subject(81, "male", false, 35, true, 299, true, 99, "human");
        
        // test this object by printing out each of the attribute values
        System.out.println("The values of otherSubject are " + otherSubject);
        
        // now change the social value and print out the object again to make sure that worked
        otherSubject.setSocialValue(32);
        System.out.println("The values of otherSubject after the change are " + otherSubject);
        
        // test new method to calculate ratio of salary to socialValue
        System.out.println("The ratio for otherSubject is " + otherSubject.calcSalaryToSocial());
        
        // Instantiate a Subject object with the default constructor that only sets a random age
        Subject defaultSubject = new Subject();
        System.out.println("The default subject is " + defaultSubject);
        defaultSubject.setGender("male");
        System.out.println("The default subject is " + defaultSubject);
    }
    
}
