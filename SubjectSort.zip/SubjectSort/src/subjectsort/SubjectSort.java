package subjectsort;

import java.util.logging.Level;
import java.util.logging.Logger;

public class SubjectSort {

    public static void main(String[] args) {

        // TODO code application logic here
        
        // driver program--uses SubjectLists to build a list of Subject objects and sort them
        // by a criterion we choose
        SubjectList theSubjects;
        try {
            // the program can sort any number of Subject objects up to the size of the file
            theSubjects = new SubjectList(30);
            // loop over the list and print ou each ratio of salary to social value
            for (Subject subject : theSubjects.getTheList()) {
                System.out.println(subject.calcSalaryToSocial());
            }
            System.out.println("\nSorted list begins");
            // tell the list to sort itself
            theSubjects.sortSubjects();
            // loop over the sorted list and print out each ratio of salary to socal value
            for (Subject subject : theSubjects.getTheList()) {
                System.out.println(subject.calcSalaryToSocial());
                // Use the toString method in the Subject class to print out each Subject object
                System.out.println(subject);
            }
        } catch (Exception ex) {
            Logger.getLogger(SubjectSort.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

}
