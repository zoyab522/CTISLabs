package subjectsort;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubjectList {

    private Subject[] theList;

    public SubjectList(int nSubjects) throws Exception {
        theList = new Subject[nSubjects];
        int iSubject = 0;
        // Read the file into an ArrayList like in Lab 10
        File sourceFile = new File("allTheSubjects.txt");
        try {
            Scanner scan = new Scanner(sourceFile);
            while (scan.hasNext() && iSubject < nSubjects) {
                int age = scan.nextInt();
                String gender = scan.next(); // next() in the Scanner class reads a String
                double socialValue = scan.nextDouble();
                boolean human = scan.nextBoolean();
                boolean pedestrian = scan.nextBoolean();
                boolean ruleFollowing = scan.nextBoolean();
                String species = scan.next();
                int weight = scan.nextInt();
                int salary = scan.nextInt();
                // keep track of the order the parameters must be used in the Subject constructor
                //int age, String gender, boolean ruleFollowing, double socialValue, boolean human, int weight, 
                //boolean pedestrian, int salary, String species
                Subject nextSubject = new Subject(age, gender, ruleFollowing, socialValue, human, weight,
                        pedestrian, salary, species);
                theList[iSubject] = nextSubject;
                iSubject = iSubject + 1;
            }
            if (nSubjects > iSubject) {
                throw new Exception("Not enough subjects in the file");
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(SubjectList.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // Start the recursive sort process by calling mergesort with the list we want to sort and the size
    // of the list
    public void sortSubjects() {
        // Claim: mergesort is a recursive algorithm
        mergeSort(theList, theList.length);
    }

    private void mergeSort(Subject[] all, int n) {
        // Adapted from https://www.baeldung.com/java-merge-sort
        // receives an array and the number of elements to sort
        if (n < 2) {
            // a one-element array is automatically sorted: this is the base case
            // let's just return
            return;
        }
        // divide the array into two; mid is the number of elements
        // in each half
        int mid = n / 2;

        // allocate and fill the two halves from the original array
        // Build two arrays, one to hold each half
        Subject[] left = new Subject[mid];
        Subject[] right = new Subject[n - mid];

        // actually divide the array in half in a left and right side
        // put the first half of the all array into left
        for (int i = 0; i < mid; i = i + 1) {
            left[i] = all[i];
        }
        // put the second half of the all array into right
        for (int i = mid; i < n; i = i + 1) {
            right[i - mid] = all[i];
        }
        // Once we've done this, we have two smaller problems

        // Solve each of the two smaller problems
        // call mergeSort to sort each of the two halves
        mergeSort(left, mid);
        mergeSort(right, n - mid);
        // only after some of the mergeSort calls start returning 
        // do we merge the results
        merge(all, left, right, mid, n - mid);
    }

    private void merge(
            Subject[] all, Subject[] left, Subject[] right, int leftIndex, int rightIndex) {
        // Adapted from https://www.baeldung.com/java-merge-sort

        int i = 0, j = 0, k = 0;
        while (i < leftIndex && j < rightIndex) {
            // decide whether the current top element of the 
            // left or right arrays has the smaller value
            // compare which Subject has the larger ratio of 
            // salary to social value
            if (left[i].calcSalaryToSocial()
                    >= right[j].calcSalaryToSocial()) {
                // sort by weight in ascending order
                // if (left[i].calcSalaryToSocial()
                //        >= right[j].calcSalaryToSocial()) {
                all[k] = left[i];
                i = i + 1;
            } else {
                all[k] = right[j];
                j = j + 1;
            }
            k = k + 1;
        }
        while (i < leftIndex) {
            all[k] = left[i];
            i = i + 1;
            k = k + 1;
        }
        while (j < rightIndex) {
            all[k] = right[j];
            k = k + 1;
            j = j + 1;
        }
    }

    public Subject[] getTheList() {
        return theList;
    }

    public void setTheList(Subject[] theList) {
        this.theList = theList;
    }

}
