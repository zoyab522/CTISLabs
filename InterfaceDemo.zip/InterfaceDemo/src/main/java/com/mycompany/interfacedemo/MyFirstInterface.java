/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.interfacedemo;

/**
 *
 * @author zoya
 * Another way to achieve abstraction in Java is using Interfaces
 * An interface is a completely "Abstract" class that is used to group related methods with empty body
 * 
 */
public interface MyFirstInterface {
    
    public void my1IFMethod(); // Interface Method
    
    
    
    
    
}
