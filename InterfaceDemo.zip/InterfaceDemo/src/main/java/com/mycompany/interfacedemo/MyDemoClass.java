package com.mycompany.interfacedemo;

/**
 *
 * @author zoya
 * Java does not support "Multiple Inheritance" using "extend"
 * a class can only inherit from one superclass
 * A class can implement multiple interfaces (separated by commas)
 */
public class MyDemoClass 
        implements MyFirstInterface, MySecondInterface {
    
    public void my1FMethod () {
        System.out.println("My 1st Interface Method;");
        
    }
    
    public void my2IFMethod() {
        System.out.println("My 2nd Interface Method;");
    }

    @Override
    public void my1IFMethod() {
        throw new UnsupportedOperationException("Not supported yet."); 
        // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
