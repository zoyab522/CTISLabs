package com.mycompany.interfacedemo;

/**
 *
 * @author zoya
 * 
 */
public class InterfaceDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        MyDemoClass myObject = new MyDemoClass();
        myObject.my1FMethod();
        myObject.my1FMethod();
        
    }
    
}
