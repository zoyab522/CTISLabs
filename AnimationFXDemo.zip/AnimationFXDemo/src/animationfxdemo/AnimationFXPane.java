package animationfxdemo;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CubicCurveTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.util.Duration;

public class AnimationFXPane extends Pane {
    private Circle animCircle;

    public AnimationFXPane() {
        animCircle = new Circle(100, 100, 50);
        animCircle.setFill(Color.RED);
        getChildren().add(animCircle);
        
        // fade an object in and out using FadeTransition
        // transitions are objects
        FadeTransition fadeT = new FadeTransition(Duration.millis(3000), animCircle);
        // Send messages to fadeT to define the nature of the transition
        fadeT.setFromValue(1.0); // fully opaque is where we start
        fadeT.setToValue(0.1); // almost transparent
        fadeT.setCycleCount(2);
        fadeT.setAutoReverse(true);
        //fadeT.play();
        
        // path transition that moves the object
        // Create a Path object that the center of the circle will follow
        Path path = new Path();
        // add to the list of stopping poitns for the ath
        path.getElements().add(new MoveTo(200, 300));
        path.getElements().add(new LineTo(300, 200));
        path.getElements().add(new CubicCurveTo(100, 100, 200, 200, 50, 50));
        // Build a path transition that has a duration, a path, and a target
        PathTransition pathT = new PathTransition(Duration.millis(5000), path, animCircle);
        pathT.setCycleCount(4);
        pathT.setAutoReverse(true);
        //pathT.play();
        
        SequentialTransition seqT = new SequentialTransition();
        seqT.getChildren().addAll(fadeT, pathT);
        seqT.play();
        
        
        
    }

    private Duration Duration(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
