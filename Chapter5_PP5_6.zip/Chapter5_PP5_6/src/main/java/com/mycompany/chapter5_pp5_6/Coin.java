
package com.mycompany.chapter5_pp5_6;

/**
 * @author zoya PP5.6 page 250
 */
public class Coin {

    private final int HEADS = 0;
    private final int TAILS = 1;

    private int face;

    public Coin() {
        flip(); // sets up the coin by flipping it initially
    }

    public void flip() {
        // flips the coin by randomy choosing a face value

        face = (int) (Math.random() * 2);

    }

    public boolean isHead() {
        return (face == HEADS);

    }

    public String toString() {
        String faceName;

        if (face == HEADS) {
            faceName = "Heads";
        } else {
            faceName = "Tails";
        }
        return faceName;
    }
    
    
}
