package recursivecircles;

import java.util.ArrayList;
import java.util.Random;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class RecursiveCirclePane extends Pane { // We use Pane because we want to place each object

    private double initialX = 100;
    private double initialY = 300;
    private double initialRadius = 60;
    private double reduceFactor = 0.5; //each circle will be 50% of the radius of the previous one
    private Random rand = new Random();
    private double oldX = 0;
    private double oldY = 0;
    private ArrayList<Circle> allCircles;

    // need a constructor to build what we're drawing in the pane
    public RecursiveCirclePane() {
        allCircles = new ArrayList<Circle>();
        // start the recursive process
        drawAllCircles();
        setOnMousePressed(this::processMousePress);

    }

    public void drawAllCircles() {
        // initiates the drawing of the circles
        System.out.println("The number of circles is "
                + addCircle(initialX, initialY, initialRadius, reduceFactor));
    }

    public int addCircle(double x, double y, double radius, double reduce) {
        // this is the recursive method that draws a new circle
        // based on the previous circle that was drawn
        Circle theCircle = new Circle(x, y, radius);
        getChildren().add(theCircle);

        // keep track of every circle added to the display in an ArrayList
        allCircles.add(theCircle);
        // Build a random color with a random opacity
        int red = rand.nextInt(256);
        int green = rand.nextInt(256);
        int blue = rand.nextInt(256);
        // largest opacity value = 0.8; smallest value = 0.3;
        double opacity = 0.5 * rand.nextDouble() + 0.3;
        Color newColor = Color.rgb(red, green, blue, opacity);

        theCircle.setFill(newColor);
        //theCircle.setStroke(Color.BLACK);
        //theCircle.setStrokeWidth(2);

        // now make it recursive
        if (radius > 2) {
            // generate a random angle between 0 and π
            double angle = 2 * Math.PI * rand.nextDouble();
            // calculate how we'll move the center of the circle
            double changeX = radius * (1 + reduceFactor) * Math.cos(angle);
            double changeY = radius * (1 + reduceFactor) * Math.sin(angle);
            // choose a random reduceFactor for the new circles
            reduceFactor = 0.3 * rand.nextDouble() + 0.6;

            // each circle to draw two new circles in opposite directions
            return addCircle(x + changeX, y + changeY, radius * reduceFactor, reduceFactor)
                    + addCircle(x - changeX, y - changeY, radius * reduceFactor, reduceFactor);
        }

        // base case: draw the final circle and return the value 1
        return 1;
    }

    public void processMousePress(MouseEvent event) {
        // clear the screen of all existing circles
        getChildren().clear();
        // grab the position of the mouse
        initialX = event.getX();
        initialY = event.getY();
        // generate a random initial radius
        initialRadius = 40 + rand.nextInt(60);
        // use that position and radius to start the recursive process over again
        drawAllCircles();
    }
    
}

    