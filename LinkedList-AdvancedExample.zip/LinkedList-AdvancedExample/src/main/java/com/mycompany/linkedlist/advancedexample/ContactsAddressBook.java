/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.linkedlist.advancedexample;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author zoya
 */
public class ContactsAddressBook {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<Person> CAB = new LinkedList<Person>();
        
        Address add1 = new Address ("5800 W. Friendly Ave.", "Greensboro", "NC", "27410");
        Address add2 = new Address ("5800 W. Friendly Ave.", "Greensboro", "NC", "27410");
        Address add3 = new Address ("5800 W. Friendly Ave.", "Greensboro", "NC", "27410");
        Address add4 = new Address ("5800 W. Friendly Ave.", "Greensboro", "NC", "27410");
        Address add5 = new Address ("5800 W. Friendly Ave.", "Greensboro", "NC", "27410");
        
        CAB.add(new Person("Martin", "Scorsese", add1, 2211333));
        Person per2  = new Person("Mark", "Wahlberg", add2, 11122333);
        CAB.add(per2);
        
        CAB.add(new Person("Matt", "Damon", add3, 33311222));
        
        CAB.add(new Person("Leonardo", "DiCaprio", new Address("800 W. Market St.", 
                "Greensboro", "NC", "27409"), 1122333));
        
        CAB.add(new Person("Jack", "Nicholson", add5, 55522333));
        
        for(Person element : CAB)
            System.out.println(element + "\n");
        
        System.out.println("First element of LinkedList is" 
                + CAB.getFirst()); 
        System.out.println("First element of LinkedList is" 
                + CAB.getLast());
        
        System.out.println(CAB);
        
        System.out.println("\n\n SUBLIST");
        List subList = CAB.subList(1, 2);
        System.out.println("SubList is:\n" + subList);
        
        subList.remove(2);
        System.out.println("New SubList is:\n" + subList);
        
        System.out.println(CAB);
        Person Per4 = new Person("Martin", "Sheen",
                        add4, 44422111);
        CAB.addFirst(Per4);
        
        Person Per5 = new Person("Anthony", "Anderson", 
                        add5, 55511333);
        CAB.addLast(Per5);
        System.out.println("Removing the nth element of a specific element from the LinkedList: ");
        CAB.remove(2);
        System.out.println(CAB);
        CAB.removeLast();
        System.out.println(CAB);
        
        System.out.println("Removing the first and last elements from the LinkedList:");
        CAB.removeFirst();
        CAB.removeLast();
        
        System.out.println("Removing a range of elements:");
        CAB.subList(2, 3).clear();
        
        System.out.println("Retrieving the ends (first and last) elements from the LinkedList:");
        
        System.out.println(CAB.getFirst());
        System.out.println(CAB.getLast());
        
        System.out.println("Removing all the elements from the LinkedList:");
        //System.out.println(CAB.clear());
    }   
    
}
