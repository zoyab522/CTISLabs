/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.linkedlist.advancedexample;

/**
 *
 * @author zoya
 */
public class Person extends Address{
    
    private String firstName;
    private String lastName;
    protected Address address;
    private long SSN;
    
    public Person(String firstName, String lastName, Address address, long SSN) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.SSN = SSN;   
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Address getAddress() {
        return address;
    }

    public long getSSN() {
        return SSN;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void setSSN(long SSN) {
        this.SSN = SSN;
    }

    @Override
    public String toString() {
        return "Person{" + "firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", SSN=" + SSN + '}';
    }
    
    
    
}
