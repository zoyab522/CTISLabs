/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * A binary tree is a recursive data structure
 * where each node can have 2 children at most.
 * 
 */
package com.mycompany.binarytree;

/**
 *
 * @author zoya
 */

/*
 * class containing left & right child of current node,
 * and key value
*/
public class Node {
    int key;
    Node left, right;
    
    public Node (int item) //constructor
    {
        key = item;
        left = right = null;
    }
    
    
}
