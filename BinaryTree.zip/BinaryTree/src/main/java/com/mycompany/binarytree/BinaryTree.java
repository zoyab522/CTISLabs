/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.binarytree;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author zoya
 */

//intro to Binary Tree data structure.
public class BinaryTree {
    Node root; //Root of the binary tree
    
    
    //------------------ Constructor1
    BinaryTree ()
    {
        root = null;
    }
    
    //------------------ Constructor2
    BinaryTree(int key)
    {
        root = new Node(key);
    }
            
    //------------------- Tree Traversal
    /*
    Depth-first search is a trype of traversal that goes
    deep as much as possible in every child before 
    exploring the next sibling;
    
    There are several ways to perform a depth-first search:
    in-order, pre-order, and post-order;
    
    In-order traversal consists of first visiting 
    the left sub-tree, 
    then the root node, 
    and finally the right sub-tree;
    
    Pre-order traversal consists of first visiting
    the root node,
    then the left sub-tree.
    and finally the right sub-tree;
    
    Post-order traversal consists of first visiting
    the left sub-tree,
    then the right sub-tree,
    and finally the root node at the end;
    */
   
    void printPostorder(Node node)
    {
        if (node == null)
            return;
        
        //first recur on the left sub-tree
        printPostorder(node.left);
        //then recur on the right sub-tree
        printPostorder(node.right);
        
        //Now handle the node
        System.out.print(node.key + " ");
        
    }
    
    void printInorder(Node node)
    {
        if (node == null)
            return;
        //first recur on left child
        printInorder(node.left);
        //then print the data of the node
        System.out.print(node.key + " ");
        //now recur on right child
        printInorder(node.right);
    }
    
    void printPreorder (Node node)
    {
        if (node == null)
            return;
        //first print data of the node
        System.out.print(node.key + " ");
        //then recur on left subtree
        printPreorder(node.left);
        //finally recur on right subtree
        printPreorder(node.right);
        
    }
    
    //Wrappers over above the recursive funtions
    void printPostorder(){ printPostorder(root);}
    void printPreorder(){ printPreorder(root);}
    void printInorder(){ printInorder(root);}
    
    
    
    /*
    Breadth-first search visits all the nodes of a level
    before going to the next (deeper) level;
    This kind of traversal is also called 
    level-order and visits all the levels of the tree
    starting from the root, and from left to right;
    
    To implement BFT, we'll use a queue to hold the nodes
    from each level in order. Then we'll extract each node
    from the list, print its value, then add its children 
    to the queue;
    
    */
    
    void printLevelOrder()
    {
        int h = height(root);
        int i;
        for (i = 1; i<= h; i++)
            printGivenLevel(root, i);
    }
    
    /*
    Compute the "height of the tree: 
    the number of nodes along the longest path 
    from the root node down to the farthest leaf node
    */
    int height (Node root)
    {
        if (root == null)
            return 0;
        else
        {
            //compute the height of each subtree
            int lheight = height(root.left);
            int rheight = height(root.right);
            
            //use the larger height
            if (lheight > rheight)
                return (lheight+1);
            else 
                return (rheight+1);
        }
    }
    
    //print nodes at the given level
    void printGivenLevel(Node root, int level)
    {
        if (root == null)
            return;
        if (level == 1)
            System.out.print(root.key + " ");
        else if (level > 1)
        {
            printGivenLevel(root.left, level-1);
            printGivenLevel(root.right, level-1);
        }
         
    }
    
    void printLevelOrder1()
    { //given a binary tree, print its nodes in 
      //level order using a linked list to implemt a queue
      
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(root);
        
        while (!queue.isEmpty())
        {
            //poll() removes the present head or node at 
            //the begining of the queue
            Node tempNode = queue.poll();
            System.out.print(tempNode.key + " ");
            
            //enqueue left child
            if (tempNode.left != null)
                queue.add(tempNode.left);
            //enqueue right child
            if (tempNode.right != null)
                queue.add(tempNode.right);
        }
    }
    
    /*
    Compute the maxdepth of a tree:
    the number of nodes along the longest path
    from the root node down to the farthest leaf node.
    */
    int maxDepth(Node node)
    {
        if (node == null)
            return 0;
        else
        {
            //compute the max depth of each subtree
            int lDepth = maxDepth(node.left);
            int rDepth = maxDepth(node.right);
            
            //use the larger depth
            if (lDepth > rDepth)
                return (lDepth + 1);
            else
                return (rDepth + 1);
        }
    }
    
    /*
    Given a binary tree, print all of its root-to-leaf
    paths, one path per line. 
    Use a recursive helper method to do the work.
    */
    void printPaths(Node node)
    {
        //use array
        int path[] = new int[1000];
        printPathsRecur(node, path, 0);
        //recursive helper method
    }
    
    /*
    Recursive helper method: given a node, an array 
    containing the path from the root node up to but
    not including this node, print all the root-leaf paths.
    */
    void printPathsRecur(Node node, int path[], int pathLen)
    {
        if (node == null)
            return;
        //append this node to the path array
        path[pathLen] = node.key;
        pathLen++;
        
        //Check if it is a leaf, 
        //print the path that lead to here
        if (node.left == null && node.right == null)
            printArray(path, pathLen);
        else
        {
            //Check both subtrees
            printPathsRecur(node.left, path, pathLen);
            printPathsRecur(node.right, path, pathLen);
        }
    }
    
    void printArray(int arr[], int len)
    //method that prints out an array of int on a line
    {
        int i;
        for (i = 0; i < len; i++)
            System.out.print(arr[i] + " ");
        System.out.println("");
    }
    
    
    //this method returns 1 if children sum property
    //holds for the given node and both of its children
    int isSumProperty(Node node)
    {
        //leftData is left chid data
        //rightData is right child data
        
        int leftData = 0, rightData = 0;
        
        if (node == null || 
                (node.left == null && node.right == null))
            return 1; //true
        else
        {
            //check if left child is not present then 
            //0 is used as data of left child
            if (node.left != null)
                leftData = node.left.key;
            
            //check if right child is not present then 
            //0 is used as data of right child
            if (node.right != null)
                rightData = node.right.key;
            
            //if the node and both of its children satisfy
            //the property return 1 else return 0
            if ((node.key == leftData + rightData)
                    && (isSumProperty(node.left)!= 0)
                    && (isSumProperty(node.right)!=0))
                return 1;
            else
                return 0;
            
        }
    }
    
    
}
