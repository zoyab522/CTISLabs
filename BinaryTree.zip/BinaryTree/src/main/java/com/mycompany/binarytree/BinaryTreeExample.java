/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.binarytree;

public class BinaryTreeExample {

    public static void main(String[] args) {
        BinaryTree Btree = new BinaryTree();
        
        //create root
        Btree.root = new Node(1);
        //The result of the statement above is a tree
        /*
                            |        
                            1
                          /   \
                        null  null
        
        */
        
        Btree.root.left = new Node(2);
        Btree.root.right = new Node (3);
        /*
                            |        
                            1
                          /   \
                         2     3
                       /  \   /  \
                    null null null null 
        */
        Btree.root.left.left = new Node(4);
        Btree.root.left.right = new Node(5);
        Btree.root.right.left = new Node (6);
        Btree.root.right.right = new Node (7);
        
        Btree.root.left.left.left = new Node(8);
        
        /*
                            |        
                            1
                          /   \
                         2     3
                       /  \   /  \
                     4    5  6     7
                   / \   / \ / \   / \
                  8  N  N  N N N  N   N 
                 / \
             null  null
        */
        
        
        System.out.println("Preorder Traversal of"
                + " binary tree is: ");
        Btree.printPreorder();
        
        System.out.println("\nInorder Traversal of"
                + " binary tree is: ");
        Btree.printInorder();
        
        System.out.println("\nPostorder Traversal of"
                + " binary tree is: ");
        Btree.printPostorder();
        
        System.out.println("\n\n"
                + "The Height of Btree is: "
                + Btree.maxDepth(Btree.root));
        
        //print all the root-to-leaf paths of the Btree
        Btree.printPaths(Btree.root);
        
        if (Btree.isSumProperty(Btree.root) != 0)
            System.out.println("This given Btree satisfies"
                    + " Children sum property");
        else 
            System.out.println("This given Btree does not satisfy"
                    + " Children sum property");
        
        System.out.println("\n\n"
                + "Level order traversal of this Btree is:");
        Btree.printLevelOrder();
        System.out.println("\n\n"
                + "Level order traversal1 of this Btree is:");
        Btree.printLevelOrder1();
    }
    
}
