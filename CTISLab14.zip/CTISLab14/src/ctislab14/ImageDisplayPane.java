package ctislab14;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

public class ImageDisplayPane extends Pane {

    private ImageView image1, image2;
    private boolean move = false, drag = false;

    public ImageDisplayPane() {

        Image picture1 = new Image("file:picture1.png");
        Image picture2 = new Image("file:picture2.jpg");

        image1 = new ImageView(picture1);
        image1.setX(400);
        image1.setOnMouseMoved(this::processMouseMove);
        image1.setOnMouseDragged(this::processMouseDrag);
        image1.setFocusTraversable(true);
        image1.setOnKeyTyped(this::processKeyType);

        image2 = new ImageView(picture2);
        image2.setY(100);
        image2.setOnMouseMoved(this::processMouseMove);
        image2.setOnMouseDragged(this::processMouseDrag);
        image2.setFocusTraversable(true);
        image2.setOnKeyTyped(this::processKeyType);

        getChildren().add(image1);
        getChildren().add(image2);

    }

    public void processMouseMove(MouseEvent event) {
        double xEvent = event.getX();
        double yEvent = event.getY();
        System.out.println(xEvent + " " + yEvent);

    }

    public void processMouseDrag(MouseEvent event) {
        if (event.getSource() == image1) {
            double newX = event.getX();
            double newY = event.getY();
            image1.setX(newX);
            image1.setY(newY);
        } else if (event.getSource() == image2) {
            double newX = event.getX();
            double newY = event.getY();
            image2.setX(newX);
            image2.setY(newY);

        }

    }

    public void processKeyType(KeyEvent event) {

        // use TAB key to switch between images to move with the character keys
        if (event.getSource() == image1) {
            if (event.getCharacter().equals("k")) {
                image1.setY(image1.getY() + 5);
            } else if (event.getCharacter().equals("j")) {
                image1.setY(image1.getY() - 5);
            } else if (event.getCharacter().equals("i")) {
                image1.setX(image1.getX() - 5);
            } else if (event.getCharacter().equals("l")) {
                image1.setX(image1.getX() + 5);
            } else if (event.getCharacter().equals("e")) {
                image1.setRotate(image1.getRotate() + 5);
            } else if (event.getCharacter().equals("w")) {
                image1.setRotate(image1.getRotate() - 5);
            }
        } else if (event.getSource()
                == image2) {
            if (event.getCharacter().equals("k")) {
                image2.setY(image2.getY() + 5);
            } else if (event.getCharacter().equals("j")) {
                image2.setY(image2.getY() - 5);
            } else if (event.getCharacter().equals("i")) {
                image2.setX(image2.getX() - 5);
            } else if (event.getCharacter().equals("l")) {
                image2.setX(image2.getX() + 5);
            } else if (event.getCharacter().equals("e")) {
                image2.setRotate(image2.getRotate() + 5);
            } else if (event.getCharacter().equals("w")) {
                image2.setRotate(image2.getRotate() - 5);
            }
        }
    }

}
