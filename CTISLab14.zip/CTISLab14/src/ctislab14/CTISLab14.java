package ctislab14;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class CTISLab14 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        ImageDisplayPane root = new ImageDisplayPane();
        
        Scene scene = new Scene(root, 800, 600);
        
        primaryStage.setTitle("Lab 14 Image Display");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
