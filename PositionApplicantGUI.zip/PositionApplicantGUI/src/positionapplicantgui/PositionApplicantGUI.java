package positionapplicantgui;
// implements specification 1
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class PositionApplicantGUI extends Application {

    @Override
    public void start(Stage primaryStage) {

        PositionApplicant testApplicant = new PositionApplicant("Arthur Weasely", "Programmer III",
                4, 98, 95.62, 81.9, 16.4, 23.53, 86.48, 17.34); // implements specification 10

        PositionApplicantPane root = new PositionApplicantPane(testApplicant);
        
        Background applicant1Fill = new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY));
        root.setBackground(applicant1Fill);

        PositionApplicantPane PositionApplicant = new PositionApplicantPane();

        PositionApplicant testApplicant1 = new PositionApplicant("Nymphadora Tonks", "Programmer I",
                0, 100, 94.23, 93.67, 97.6, 89.45, 79.32, 90.45); // implements specification 10

        PositionApplicantPane secondRoot = new PositionApplicantPane(testApplicant1); 
        
        Background applicant2Fill = new Background(new BackgroundFill(Color.LIGHTPINK, CornerRadii.EMPTY, Insets.EMPTY));
        secondRoot.setBackground(applicant2Fill);

        HBox applicantGroup = new HBox();

        applicantGroup.getChildren().add(root);
        applicantGroup.getChildren().add(secondRoot);

        Scene scene = new Scene(applicantGroup, 1020, 650);

        primaryStage.setTitle("Position Applicants");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
