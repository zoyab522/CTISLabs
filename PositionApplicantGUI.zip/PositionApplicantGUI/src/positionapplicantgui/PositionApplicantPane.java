package positionapplicantgui;
// implements specification 1

import java.text.DecimalFormat;
import java.util.Random;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class PositionApplicantPane extends FlowPane {       // implements specification 6

    private PositionApplicant applicant;                    // implements specification 6
    private Label applicantLabel;                           // implements specification 6
    private TextField nameField;
    private TextField numberField;
    private Label nameFieldLabel;
    private Label numberFieldLabel;
    private TextField introCompProg;
    private Label introCompProgLabel;
    private Label analyze2Label;
    private Label analyze5Label;
    private Button randomizeButton;
    private Slider introSlider;
    private double introValue;
    private Label introSliderLabel;
    private GridPane scoreChange;
    private Slider advSlider;
    private double advValue;
    private Label advSliderLabel;

    public PositionApplicantPane() {
    }

    public PositionApplicantPane(PositionApplicant applicant) {
        this.applicant = applicant;
        applicantLabel = new Label(applicant.toString());   // implements specification 8

        Font ApplicantFont1 = Font.font("Helvetica", FontWeight.BOLD, 15);

        nameField = new TextField(applicant.getApplicantName());
        nameField.setOnAction(this::processNameReturn);
        nameFieldLabel = new Label("Change the Applicant Name");
        nameFieldLabel.setFont(ApplicantFont1);

        numberField = new TextField("" + applicant.getApplicantNumber());
        numberField.setOnAction(this::processNumberReturn);
        numberFieldLabel = new Label("Change Applicant Number");
        numberFieldLabel.setFont(ApplicantFont1);

        introCompProg = new TextField("" + applicant.getIntroCompProg());
        introCompProg.setOnAction(this::processIntroCompProg);
        introCompProgLabel = new Label("\tChange Intro Comp Prog Score");
        introCompProgLabel.setFont(ApplicantFont1);

        analyze2Label = new Label("\tMethod 2: " + applicant.analyze_applicant2());
        analyze2Label.setFont(ApplicantFont1);
        analyze5Label = new Label("\tMethod 5: " + applicant.analyze_applicant5());
        analyze5Label.setFont(ApplicantFont1);

        randomizeButton = new Button("Randomize!");
        randomizeButton.setOnAction(this::processButtonPress);

        applicantLabel.setPrefWidth(510); // implements specification 9 
        applicantLabel.setWrapText(true); // implements specification 9 
        Font ApplicantFont = Font.font("Montserrat", FontWeight.BOLD, 20); // implements specification 9
        applicantLabel.setFont(ApplicantFont);

        introValue = applicant.getIntroCompProg();
        scoreChange = new GridPane();
        introSlider = new Slider(0, 100, introValue);
        SliderListener sliderListener = new SliderListener();
        introSlider.valueProperty().addListener(sliderListener);
        introSliderLabel = new Label("\tIntro " + introValue);
        introSliderLabel.setFont(ApplicantFont1);
        introSlider.setMajorTickUnit(20);
        introSlider.setMinorTickCount(5);
        introSlider.setShowTickMarks(true);
        introSlider.setShowTickLabels(true);

        advValue = applicant.getAdvCompProg();
        advSlider = new Slider(0, 100, advValue);
        advSlider.valueProperty().addListener(sliderListener);
        advSliderLabel = new Label("\tAdv " + advValue);
        advSliderLabel.setFont(ApplicantFont1);
        advSlider.setMajorTickUnit(20);
        advSlider.setMinorTickCount(5);
        advSlider.setShowTickMarks(true);
        advSlider.setShowTickLabels(true);

        getChildren().add(applicantLabel);
        getChildren().add(nameField);
        getChildren().add(nameFieldLabel);
        getChildren().add(numberField);
        getChildren().add(numberFieldLabel);
        getChildren().add(introCompProg);
        getChildren().add(randomizeButton);
        getChildren().add(introCompProgLabel);
        getChildren().add(analyze5Label);
        getChildren().add(analyze2Label);
        getChildren().add(scoreChange);

        scoreChange.add(introSliderLabel, 0, 0);
        scoreChange.add(introSlider, 1, 0);

        scoreChange.add(advSliderLabel, 0, 1);
        scoreChange.add(advSlider, 1, 1);

    } //implements specification 7

    public void processNameReturn(ActionEvent event) {      // change applicant name
        //System.out.println(nameField.getText());
        applicant.setApplicantName(nameField.getText());
        applicantLabel.setText(applicant.toString());
    }

    public void processNumberReturn(ActionEvent event) {    // change applicant number
        applicant.setApplicantNumber(Integer.parseInt(numberField.getText()));
        applicantLabel.setText(applicant.toString());
    }

    public void processIntroCompProg(ActionEvent event) {   // change introCompProg value
        applicant.setIntroCompProg(Integer.parseInt(introCompProg.getText()));
        applicantLabel.setText(applicant.toString());
        analyze5Label.setText("\tMethod 5: " + applicant.analyze_applicant1());
        analyze2Label.setText("\tMethod 2: " + applicant.analyze_applicant1());

    }

    public void processButtonPress(ActionEvent event) {
        Random rand = new Random();
        double newValue = rand.nextDouble() * 50 + 50;
        applicant.setIntroCompProg((int) newValue);
        applicantLabel.setText(applicant.toString());
        analyze2Label.setText("\tMethod 2: " + applicant.analyze_applicant2());
        analyze5Label.setText("\tMethod 5: " + applicant.analyze_applicant1());

    }

    public PositionApplicant getApplicant() {
        return applicant;
    }

    public void setApplicant(PositionApplicant applicant) {
        this.applicant = applicant;
    }

    private class SliderListener implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
            introValue = introSlider.getValue();
            DecimalFormat fmt = new DecimalFormat("0.00");
            introSliderLabel.setText("\tIntro " + fmt.format(introValue));
            applicant.setIntroCompProg((int) introValue);
            applicantLabel.setText(applicant.toString());
            analyze2Label.setText("\tMethod 2: " + applicant.analyze_applicant2());
            analyze5Label.setText("\tMethod 5: " + applicant.analyze_applicant1());

            advValue = advSlider.getValue();
            advSliderLabel.setText("\tAdv " + fmt.format(advValue));
            applicant.setAdvCompProg(advValue);
            applicantLabel.setText(applicant.toString());
            analyze2Label.setText("\tMethod 2: " + applicant.analyze_applicant2());

        }

    }

}
