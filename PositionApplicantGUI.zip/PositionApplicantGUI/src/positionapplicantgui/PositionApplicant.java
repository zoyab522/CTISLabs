package positionapplicantgui;
// implements specification 1
import javafx.scene.text.Font;

public class PositionApplicant {

    private String applicantName = "Nymphadora Tonks";      // implements specification 2
    private String positionName = "Programmer I";           // implements specification 2
    private int applicantNumber = 0;                        // implements specification 2
    private int introCompProg = 100;                        // implements specification 2
    private double advCompProg = 94.23;                     // implements specification 2
    private double OperatingSystems = 93.67;                // implements specification 2
    private double Networking = 97.6;                       // implements specification 2
    private double DataBaseSys = 89.45;                     // implements specification 2
    private double algorithms = 79.32;                      // implements specification 2
    private double overallGPA = 90.45;                      // implements specification 2
    private double averageScore = 83.3;                     // implements specification 2

    public PositionApplicant(String applicantName) {
        this.applicantName = applicantName;
    } // implements specification 4

    public PositionApplicant(String applicantName, String positionName, int applicantNumber, int introCompProg,
            double advCompProg, double OperatingSystems, double Networking, double DataBaseSys, double Algorithms, 
            double OverallGPA) {
        this.applicantName = applicantName;
        this.positionName = positionName;
        this.applicantNumber = applicantNumber;
        this.introCompProg = introCompProg;
        this.advCompProg = advCompProg;
        this.OperatingSystems = OperatingSystems;
        this.Networking = Networking;
        this.DataBaseSys = DataBaseSys;
        this.algorithms = Algorithms;
        this.overallGPA = OverallGPA;
    } // implements specification 4

    PositionApplicant(String name, int applicantNum, int introToCompProg, double advCompProg, double networking, 
            double databaseSystems, double algorithms, double operatingSystems, double overallGPA, String position) { 
    }

    PositionApplicant(String arthur_Weasely, String programmer_III, int i, double d, double d0) {
    }

    public String getApplicantName() {
        return applicantName;
    } // implements specificaiton 3

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;

    } // implements specificaiton 3

    public String getpositionName() {
        return positionName;
    } // implements specificaiton 3

    public void setpositionName(String positionName) {
        this.positionName = positionName;
    } // implements specificaiton 3

    public double getApplicantNumber() {
        return applicantNumber;
    } // implements specificaiton 3

    public void setApplicantNumber(int applicantNumber) {
        this.applicantNumber = applicantNumber;
    } // implements specificaiton 3

    public double getIntroCompProg() {
        return introCompProg;
    } // implements specificaiton 3

    public void setIntroCompProg(int introCompProg) {
        this.introCompProg = introCompProg;
    } // implements specificaiton 3

    public double getAdvCompProg() {
        return advCompProg;
    } // implements specificaiton 3

    public void setAdvCompProg(double advCompProg) {
        this.advCompProg = advCompProg;
    } // implements specificaiton 3

    public double getOperatingSystems() {
        return OperatingSystems;
    } // implements specificaiton 3

    public void setOperatingSystems(double OperatingSystems) {
        this.OperatingSystems = OperatingSystems;
    } // implements specificaiton 3

    public double getNetworking() {
        return Networking;
    } // implements specificaiton 3

    public void setNetworking(double Networking) {
        this.Networking = Networking;
    } // implements specificaiton 3

    public double getDataBaseSys() {
        return DataBaseSys;
    } // implements specificaiton 3

    public void setDataBaseSys(double DataBaseSys) {
        this.DataBaseSys = DataBaseSys;
    } // implements specificaiton 3

    public double getAlgorithms() {
        return algorithms;
    } // implements specificaiton 3

    public void setAlgorithms(double Algorithms) {
        this.algorithms = Algorithms;
    } // implements specificaiton 3
    
    public double getOverallGPA() {
        return overallGPA;
    } // implements specificaiton 3
    
    public void setOverallGPA(double OverallGPA) {
        this.overallGPA = OverallGPA;
    } // implements specificaiton 3

    public double calculateAverageScore() {

        double averageScore;
        averageScore = (introCompProg + advCompProg + OperatingSystems + Networking + DataBaseSys + algorithms) / 6;

        return averageScore;

    }

    public double calculateStandardDeviation() {
        double standardDeviation
                = Math.sqrt(((Math.pow(introCompProg, 2.))
                        + (Math.pow(advCompProg, 2.))
                        + (Math.pow(OperatingSystems, 2.))
                        + (Math.pow(Networking, 2.))
                        + (Math.pow(DataBaseSys, 2.))
                        + (Math.pow(algorithms, 2.))) / (6 - 1));
        return standardDeviation;
    }

    public String toString() {
        String output;

        output = "Applicant Name: " + applicantName + "\n"
                + "Position Name: " + positionName + "\n"
                + "Applicant Number: " + applicantNumber + "\n"
                + "Intro to Comp Prog: " + introCompProg + "\n"
                + "Adv Comp Prog: " + advCompProg + "\n"
                + "Operating Systems: " + OperatingSystems + "\n"
                + "Networking: " + Networking + "\n"
                + "Database Systems: " + DataBaseSys + "\n"
                + "Algorithms: " + algorithms + "\n"
                + "Average Score: " + averageScore;

        return output;
    }

    // Consider the applicant further if the score in Introduction to Computer Programming is greater than 80  
    public boolean analyze_applicant1() {
        boolean accept;
        accept = (introCompProg > 80);
        return accept;
    } // implements specification 5
    
    //Consider the candidate further if both the introCompProg and advCompProg scores are greater than 85  
    public boolean analyze_applicant2() {  
        boolean accept;  
        accept = (introCompProg > 85) && (advCompProg > 85);  
        return accept;  
    } // implements specification 5
    
    /** 
    Consider the candidate further if the overall GPA is greater than 90 or the average score 
    for computing classes is greater than 85 
    **/
    public boolean analyze_applicant3() {
        boolean accept;
        accept = overallGPA > 90 || averageScore > 85;
        return accept;
    } // implements specification 5
 
    // * Only consider applicants with a GPA > 83
    // * Don't consider applicants with a grade ≤ 60 in any course
    // * If the applicant has a grade < 76 in Intro to Comp Prog, don’t consider them
    
    public boolean analyze_applicant4() {
        boolean accept;
        accept = overallGPA > 83 && introCompProg > 76 
                && introCompProg > 60 && advCompProg > 60 && OperatingSystems > 60
                && Networking > 60 && DataBaseSys > 60 && algorithms > 60;
        return accept;
    } // implements specification 5

    /** 
     * Only consider candidate further if they have a grade ≥ 80 in Algorithms
     * Only consider candidate further if they have a grade ≥ 85 in Advanced Computer Programming
     * Only consider candidate further if they have a grade ≥ 90 in Database Systems
     * Even if the overall GPA is low this criterion prioritizes 3 classes
     * These requirements will consider the more qualified applicants even further with these high grades
     * They will also get rid of applicants who are less skilled/smart, even if they possess the GPA requirements
    **/
    
    public boolean analyze_applicant5() {
        boolean accept;
        accept = algorithms >= 80 && advCompProg >= 85 && DataBaseSys >= 90;
        return accept;
    } // implements specification 5
    
    /**
     * This evaluation system still prioritizes the grades of the most important classes by requiring an A or higher in them
     * Those three classes are Algorithms, advCompProg, and DataBaseSys
     * Not placing emphasis on Intro to Comp Prog too much as long as they have an A in advCompProg 
     * This is because advCompProg essentially branches off Intro to Comp Prog, and showing an upward trajectory is important
     * A requirement was added for a "threshold" grade in Intro to Comp Prog to narrow down the pool (just passing/C or higher)
     * Requirements were added for Networking as well, because applicants should possess those skills and not just be smart
       (a B+ or higher)
     * A similar requirement was added for Operating Systems, but with a lower requirement (a B+ or higher)
     * With those requirements, about 4 percent of applicants are selected, and since this company is so popular and because
       the applicant pool is so competitive, I think this is a reasonable "acceptance rate"
     * The remaining applicants are below 1000, so now that we have the applicants with a preferable range of grades,
       we can actually engage in a more holistic review to select the best ones
     * Overall, this method is more comprehensive by including requirements for all the classes, and gives a desired range
     * The desired range is about 1-4 percent, or close to 5 percent
     * To get the desired range, I did have to do some trial and error with the scores, but I think these are reasonable
       score ranges and they prioritize the classes/grades required well
     **/
    
    public boolean analyze_applicant6() {
        boolean accept;
        accept = algorithms >= 90 && advCompProg >= 90 && DataBaseSys >= 90 && Networking >= 85 
                && OperatingSystems >= 85 && introCompProg >= 70;
        return accept;
    } // implements specification 5

    void setFont(Font ApplicantFont) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

