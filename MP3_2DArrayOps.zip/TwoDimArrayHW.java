/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.twodimensionalarrayoperations;

import java.util.Scanner;

/**
 *
 * @author zoya
 */
public class TwoDimArrayHW extends TwoDimArrayOperationsHW {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // declare twoDimHW to be a 2-dimensional array of integers of 3 rows and 5 columns;
        int[][] twoDimHW = new int[3][5];
        
        // Insert Code here to ask the user to fill out the array
        Scanner scan = new Scanner(System.in);      
        
        System.out.println("Please fill out the (3x5) array:");
        
        // loop for rows (use i)
        for(int i = 0; i < 3; i++) {
            // loop for columns (used j)
             for(int j = 0; j < 5; j++) {
                 System.out.println("Please enter an integer value for twoDimHW["
                 + i + "][" + j + "]: ");
                  
                 // Ensure that the user doesn't enter any invalid characters
                 // Invalid characters include doubles or any letters/symbols
                 // Use !scan.hasNextInt
                 if(!scan.hasNextInt()){
                        System.out.println("Please enter a valid integer");
                        System.exit(0);
                    } else {
                     // if the input is valid, store it & keep it positive!
                     // If the user enters -1, output will still print 1
                     twoDimHW[i][j] = Math.abs(scan.nextInt()); 
                }
            }
        }
      
        // Use printArray method to print the array “twoDimHW”
        printArray(twoDimHW);
        
        // declare numbersReverse to be a 2-dimensional array
        int[][] numbersReverse;
        
        // use flipArrayHorizontally method to fill it out by flipping the “twoDimHW” horizontally;
        numbersReverse = flipArrayHorizontally(twoDimHW);
        
        // Use printArray method to print the array “numbersReverse”
        System.out.println("Flipping the array Horizontally:");
        printArray(numbersReverse);

        // declare flipArrVer to be a 2-dimensional array
        int[][] flipArrVer;
        
        // use flipArrayVertically method to fill it out by flipping the “twoDimHW” vertically;
        flipArrVer = flipArrayVertically(twoDimHW);
        
        // Use printArray method to print the array “flipArrVer”
        System.out.println("Flipping the array vertically:");
        printArray(flipArrVer);

        // declare reverseArr to be a 2-dimensional array 
        int[][] reverseArr;
        
        // use reverseArray method to fill it out by reversing the “twoDimHW”;
        reverseArr = reverseArray(twoDimHW);
        
        // Use printArray method to print the array “reverseArr”
        System.out.println("Reversing the array:");
        printArray(reverseArr);
       
        // declare transpArr to be a 2-dimensional array
        int[][] transpArr;
        
        // use transposeArray method to fill it out by transposing the “twoDimHW”;
        transpArr = transposeArray(twoDimHW);
        
        // Use printArray method to print the array “transposeArray”
        System.out.println("Transposing the array:");
        printArray2(transpArr);
        
        // declare reverseTranspArr to be a 2-dimensional array 
        int[][] reverseTranspArr;
        
        // use reverseTransposeArray method to fill it out by reversing and transposing the “twoDimHW”;
        reverseTranspArr = reverseTransposeArray(twoDimHW);
        
        // Use printArray method to print the array “reverseTranspArr”
        System.out.println("Reversing and transposing the array:");
        printArray2(reverseTranspArr);

        // Use printArray method to print the array “twoDimHW”
        printArray(twoDimHW);

        // Apply the getTotal method on the “twoDimHW” array
        System.out.println("Total of twoDimHW: " + getTotal(twoDimHW));
        
        // Apply the getAverage method on the “twoDimHW” array
        System.out.println("Average of twoDimHW: " + getAverage(twoDimHW));
        
        // Apply the getRowTotal method on row 0 of the “twoDimHW” array
        System.out.println("Total of row 0 of twoDimHW: " + getRowTotal(twoDimHW, 0));
        
        // Apply the getRowTotal method on row 1 of the “twoDimHW” array
        System.out.println("Total of row 1 of twoDimHW: " + getRowTotal(twoDimHW, 1));
        
        // Apply the getColumnTotal method on column 0 of the “twoDimHW” array
        System.out.println("Total of col 0 of twoDimHW: " + getColumnTotal(twoDimHW, 0));
        
        // Apply the getColumnTotal method on column 2 of the “twoDimHW” array
        System.out.println("Total of col 2 of twoDimHW: " + getColumnTotal(twoDimHW, 2));
        
        // Apply the getHighestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Highest in row 0 of twoDimHW: " + getHighestInRow(twoDimHW, 0));
        
        // Apply the getHighestInRow method on row 1 of the “twoDimHW” array
        System.out.println("Highest in row 1 of twoDimHW: " + getHighestInRow(twoDimHW, 1));
        
        // Apply the getLowestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Lowest in row 0 of twoDimHW: " + getLowestInRow(twoDimHW, 0));
        
        // Apply the getLowestInRow method on row 1 of the “twoDimHW” array
        System.out.println("Lowest in row 1 of twoDimHW: " + getLowestInRow(twoDimHW, 1));
    }  
}
