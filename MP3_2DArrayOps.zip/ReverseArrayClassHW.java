/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.twodimensionalarrayoperations;

/**
 *
 * @author zoya
 */
public class ReverseArrayClassHW {
    
    static int[][] flipArrayHorizontally(int[][] original){
        int [][] arr = new int[3][5];
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 5; j++){
                arr[2 - i][j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] flipArrayVertically(int[][] original){
        int [][] arr = new int[3][5];
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 5; j++){
                arr[i][4 - j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] reverseArray(int[][] original){     
        int [][] arr = new int[3][5];
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 5; j++){
                arr[2 - i][4 - j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] reverseTransposeArray(int[][] original) {
        int[][] arr = new int[5][3];
        for (int i = 0; i < 5; i++){
            for(int j = 0; j < 3; j++){
                arr[4 - i][2 - j] = original[j][i];
            }
        }
        return arr;
    }
    
    static int[][] transposeArray(int[][] original){     
        int [][] arr = new int[5][3];
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 3; j++){
                arr[i][j] = original[j][i];
            }
        }
        return arr;
    }
    
}
