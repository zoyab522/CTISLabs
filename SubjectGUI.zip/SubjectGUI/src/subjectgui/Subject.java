package subjectgui;

// This is the Subject class definition, and it is not a runnable program on its own

import java.util.Random;


public class Subject {
    
    // start declaring some attributes
    private int age; // NetBeans makes attribute identifiers green
    private String gender;
    private boolean ruleFollowing;
    private double socialValue;
    private boolean human;
    private int weight;
    private boolean pedestrian;
    private int salary;
    private String species;
    
    // constructors
    // empty constructor--all it does (at first) is return an object with no attributes initialized
    // it simply reserves memory for that object
    public Subject() {
        // change the constructor behavior so that it assigns random values to the attributes
        Random rand = new Random();
        // generate a random age between 0 and 110 inclusive. What message do we send to rand to do that?
        age = rand.nextInt(111);
        // generate a random socialValue between 1 and 50
        socialValue = rand.nextDouble() * 49.0 + 1.0;
        // generate a random number between 1 and 3
        int number1 = rand.nextInt(3) + 1;
        // decide what species this is--program control using a conditional statement
        human = rand.nextBoolean();
        if (human) {
            species = "human"; // number1 == 0 is true
        }
        else if (number1 == 1) {
            species = "dog"; // number1 == 0 is false and number1 == 1 is true
        }
        else if (number1 == 2) {
            species = "cat";
        }
        else if (number1 == 3) {
            species = "squirrel";
        }
        ruleFollowing = rand.nextBoolean();
        pedestrian = rand.nextBoolean();
        weight = rand.nextInt(291) + 10;
        salary = rand.nextInt(200) + 1;
        int number2 = rand.nextInt(3);
        if (number2 == 0 ) {
            gender = "male";
        } else if (number2 == 1) {
            gender = "female";
        } else if (number2 == 2) {
            gender = "other";
        }
        
    }
    
    // consructor with parameters--builds an object that uses exactly the data provided by whoever
    // wants the object instantiated

    public Subject(int age, String gender, boolean ruleFollowing, double socialValue, boolean human, int weight, 
            boolean pedestrian, int salary, String species) {
        this.age = age;
        this.gender = gender;
        this.ruleFollowing = ruleFollowing;
        this.socialValue = socialValue;
        this.human = human;
        this.weight = weight;
        this.pedestrian = pedestrian;
        this.salary = salary;
        this.species = species;
    }
    
    
    
    
    // behaviors
    // build some getter and setter methods

    // new method to calculate the ratio of salary to socialValue
    public double calcSalaryToSocial() {
        return salary / socialValue;
    }
    
    @Override
    public String toString() {
        return "Subject{" + "age=" + age + ", gender=" + gender + ", ruleFollowing=" + ruleFollowing 
                + ", socialValue=" + socialValue + ", human=" + human + ", weight=" + weight 
                + ", pedestrian=" + pedestrian + ", salary=" + salary + ", species=" + species + '}';
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isRuleFollowing() {
        return ruleFollowing;
    }

    public void setRuleFollowing(boolean ruleFollowing) {
        this.ruleFollowing = ruleFollowing;
    }

    public double getSocialValue() {
        return socialValue;
    }

    public void setSocialValue(double socialValue) {
        this.socialValue = socialValue;
    }

    public boolean isHuman() {
        return human;
    }

    public void setHuman(boolean human) {
        this.human = human;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public boolean isPedestrian() {
        return pedestrian;
    }

    public void setPedestrian(boolean pedestrian) {
        this.pedestrian = pedestrian;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    
    
}
