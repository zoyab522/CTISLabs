package subjectgui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SubjectGUI extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        // create a random subject
        Subject randomSubject = new Subject();
        
        // instantiate a SubjectPane using that random Subject
        SubjectPane root = new SubjectPane(randomSubject);
        
        // instantiate a second random Subject
        Subject randomSubject2 = new Subject();
        // instantiate a second SubjectPane
        SubjectPane root2 = new SubjectPane(randomSubject2);
        
        // Assign a different background color to each pane
        // Use setStyle to assign a background color to each pane
        root.setStyle("-fx-background-color:#AAAAAA");
        root2.setStyle("-fx-background-color:#00DDAA");
        
        // instantiate a VBox to hold root1 and root2
        VBox subjectBox = new VBox();
        subjectBox.getChildren().addAll(root, root2);
                
        Scene scene = new Scene(subjectBox, 800, 600);
        
        primaryStage.setTitle("Subject Objects");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
