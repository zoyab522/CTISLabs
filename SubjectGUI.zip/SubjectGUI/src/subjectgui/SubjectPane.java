package subjectgui;

import java.util.Random;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class SubjectPane extends FlowPane {
    
    // add a Subject attribute to this class
    private Subject theSubject;
    // 1. declare a Label attribute to the class--most GUI elements are attributes
    private Label subjectLabel;
    // 3a. declare and initialize attributes for the visual properties of the Label
    private double labelWidth = 600;
    private String fontFamily = "Comic Sans MS";
    private double fontSize = 20;
    // 1. declare a TextField that will allow the user to change the age of the object
    private TextField ageField;
    // 1. declare a Button that generates a random weight for the Subject
    private Button weightButton;
    private CheckBox redTextCheckBox;
    private RadioButton csRadioButton;
    private RadioButton helvRadioButton;
    private Slider fontSizeSlider;
    

    // Declare and instantiate a Random object that this object and use anywhere
    private Random rand = new Random();
    // extends means that SubjectPane can do everything FlowPane does and more
    
    // build an empty constructor
    
    public SubjectPane() {
    }
    
    // build a second constructor that takes a subject object as a parameter and assigns it to 
    // the attribute

    public SubjectPane(Subject theSubject) {
        this.theSubject = theSubject;
        
        
        redTextCheckBox = new CheckBox("Red Text");
        csRadioButton = new RadioButton("Comic Sans");
        helvRadioButton = new RadioButton("Helvetica");
        fontSizeSlider = new Slider(10, 60, fontSize);
        // 3a for radio buttons--select the initial value and put the buttons in a ToggleGroup 
        // Tell csRadioButton that it should be selected
        csRadioButton.setSelected(true);
        // Build the ToggleGroup for these RadioButtons
        ToggleGroup fontGroup = new ToggleGroup();
        // Tell each RadioButton which ToggleGroup it belongs to
        csRadioButton.setToggleGroup(fontGroup);
        helvRadioButton.setToggleGroup(fontGroup);
        
        // 5. Connect the SliderListener class to the value of the fontSizeSlider object
        // First, instantiate a SliderListener object
        SliderListener sListener = new SliderListener();
        // Second, make the connection
        fontSizeSlider.valueProperty().addListener(sListener);
        
        // 2. Instantiate the Button object with a label about what it is
        weightButton = new Button("Change the weight");
        
        // 2. Instantiate a Label object with information about theSubject
        subjectLabel = new Label(theSubject.toString());
        // 3a. Modify the visual properties of the Label attribute
        // wrap the text in the subjectLabel if it extends too far
        subjectLabel.setPrefWidth(labelWidth);
        subjectLabel.setWrapText(true);
        // change the font of subjectLabel
        Font labelFont = Font.font(fontFamily, fontSize);
        subjectLabel.setFont(labelFont);
        
        // 2. Instantiate the TextField object with the current value of the age of theSubject
        // We get that age with theSubject.getAge() and convert it to a string so that the TextField 
        // can display it
        ageField = new TextField("" + theSubject.getAge());
        // 5. Connect the processTextField event handler to this TextField
        // this::processTextField is a method reference--find the processTextField
        // behavior in this object
        ageField.setOnAction(this::processTextField);
        // 5. Connect the processButtonPress event handler to weightButton
        weightButton.setOnAction(this::processButtonPress);
        redTextCheckBox.setOnAction(this::processCheckBox);
        csRadioButton.setOnAction(this::processRadioButton);
        helvRadioButton.setOnAction(this::processRadioButton);
        // 3a for Slider adds tick marks and Labels
        fontSizeSlider.setMajorTickUnit(10);
        fontSizeSlider.setMinorTickCount(4); // 4 minor ticks between every major tick
        fontSizeSlider.setShowTickMarks(true);
        fontSizeSlider.setShowTickLabels(true);

        
        // 3. add all visual objects to the display
        getChildren().addAll(subjectLabel, ageField, weightButton, redTextCheckBox, 
                csRadioButton, helvRadioButton, fontSizeSlider);
    }
    
    // Write one event handler that responds to all radio buttons
    public void processRadioButton(ActionEvent event) {
        if (event.getSource() == csRadioButton) {
           fontFamily = "Comic Sans MS"; 
        }
        else if (event.getSource()==helvRadioButton) {
           fontFamily = "Helvetica";
        }
        // build a new font
        Font newFont = Font.font(fontFamily, fontSize);
        subjectLabel.setFont(newFont);
    }
    
    
    // Event handler to process the checkbox
    public void processCheckBox(ActionEvent event) {
        // check whether redTextCheckBox is selected
        if (redTextCheckBox.isSelected()) {
            subjectLabel.setTextFill(Color.RED);
        } else { //otherwise, set the text color to black
            subjectLabel.setTextFill(Color.BLACK);
            
        }
    }
    
    
    // 4. Write an event handler that responds to events (pressing Enter) on the TextField
    // The ActionEvent contains information about what event was generated
    public void processTextField(ActionEvent event) {
        // Get the text from the TextFiel dand convert it to an integer
        int age = Integer.parseInt(ageField.getText());
        // tell theSubject what its new age should be
        theSubject.setAge(age);
        // change the socialValue to some random number
        double socialValue = rand.nextDouble() * 49.0 + 1.0;
        theSubject.setSocialValue(socialValue);
        // update the display with the new information
        subjectLabel.setText(theSubject.toString());
    }
    
    // 4. Write an event handler for weightButton
    public void processButtonPress(ActionEvent event) {
        int weight = rand.nextInt(291) + 10;
        theSubject.setWeight(weight);
        subjectLabel.setText(theSubject.toString());
    }
    
    // 4. Write an event listener class for the fontSizeSlider
    private class SliderListener implements ChangeListener<Number> {

        @Override
        public void changed(ObservableValue<? extends Number> observable, 
                Number oldValue, Number newValue) {
            // This is the method that will run when the slider value changes once we make all the right 
            // connections
            // first, get the value that the slider was changed to and assign that to the fontSize
            fontSize = fontSizeSlider.getValue();
            // build a new Font with that font size
            Font newFont = Font.font(fontFamily, fontSize);
            // set the font of the label
            subjectLabel.setFont(newFont);
        } // end of method body for changed
        
    }
    

    
}
