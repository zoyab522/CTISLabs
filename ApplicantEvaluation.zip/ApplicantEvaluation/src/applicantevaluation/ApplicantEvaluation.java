/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package applicantevaluation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author zoya
 */
public class ApplicantEvaluation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<PositionApplicant> applicants = new ArrayList<PositionApplicant>();

        PositionApplicant testApplicant = new PositionApplicant("Arthur Weasely", "Programmer III",
                46, 95.62, 81.9, 16.4, 23.53, 86.48, 17.34, 93.47);
        System.out.println("Test Applicant Name: " + testApplicant.getApplicantName());
        System.out.println("Test Applicant Intro Comp Prog Score: " + testApplicant.getIntroCompProg());
        System.out.println("Test Applicant Overall GPA: " + testApplicant.getOverallGPA());
        System.out.println("Test Applicant Advanced Comp Prog Score: " + testApplicant.getAdvCompProg());

        applicants.add(testApplicant);
        System.out.println("\nThe size of the list is " + applicants.size());
        //String testString = "Will this work?";
        //applicants.add(testString);

        PositionApplicant testItem = applicants.get(0);
        System.out.println("\nTest Applicant Name: " + testItem.getApplicantName());
        System.out.println("Test Applicant Overall GPA: " + testItem.getOverallGPA());
        System.out.println("Test Applicant Algorithms: " + testItem.getAlgorithms());
        System.out.println("\nApplicant Information:\n" + applicants.get(0));
        
        applicants.remove(0);
        System.out.println("\nThe size of the list is " + applicants.size());
        
         try  
        {
            //Scanner fileScan = new Scanner(new File("someApps.txt"));
            
            Scanner fileScan = new Scanner(new File("alltheApps.txt"));
            Random randGenerator = new Random();  
            while (fileScan.hasNext()) {  
                double introToCompProg = fileScan.nextDouble();  
                double advCompProg = fileScan.nextDouble();  
                double networking = fileScan.nextDouble();  
                double databaseSystems = fileScan.nextDouble();  
                double algorithms = fileScan.nextDouble();  
                double operatingSystems = fileScan.nextDouble();  
                double overallGPA = fileScan.nextDouble();  
                double applicantNum = randGenerator.nextInt(1000000);  
                String name = "Applicant";  
                String position = "Programmer";  
                PositionApplicant theApplicant = new PositionApplicant(name,
                        position, applicantNum, introToCompProg, advCompProg, 
                        networking, databaseSystems, algorithms, operatingSystems,
                        overallGPA);  
                    applicants.add(theApplicant);  
            }

            System.out.println("\nThe number of applicants is " + applicants.size());    

            fileScan.close();  
        }
        catch (FileNotFoundException e)  
        {
            System.out.println(e);  
            System.exit(0);  
        }
        
        int countApproved = 0;  
        for (PositionApplicant app : applicants) {  
            if (app.analyze_applicant1()) {  
                countApproved = countApproved + 1;  
            }
        }
        
        System.out.println("\nNumber of applicants approved: " + countApproved);
        
        //double percentageApproved = (countApproved * 100) / 10; //calculating percentage approved
        
        double percentageApproved = (countApproved * 100) / 18357; //calculating percentage approved

        System.out.println("Percentage of applicants approved: " + percentageApproved + "%");
        
        int countApproved2 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant2()) {
                countApproved2 = countApproved2 + 1;
            }
        }
        
        System.out.println("\nNumber of applicants approved in second method: " + countApproved2);
        
        //double percentageApproved2 = (countApproved2 * 100) / 10; 
        
        double percentageApproved2 = (countApproved2 * 100) / 18357; 

        System.out.println("Percentage of applicants approved in second method: " + percentageApproved2 + "%");
        
        int countApproved3 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant3()) {
                countApproved3 = countApproved3 + 1;
            }
        }
        
        System.out.println("\nNumber of applicants approved in third method: " + countApproved3);
        
        //double percentageApproved3 = (countApproved3 * 100) / 10;
        
        double percentageApproved3 = (countApproved3 * 100) / 18357;

        System.out.println("Percentage of applicants approved in third method: " + percentageApproved3);
        
        int countApproved4 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant4()) {
                countApproved4 = countApproved4 + 1;
            }
        }
        
        System.out.println("\nNumber of applicants approved in fourth method: " + countApproved4);
        
        //double percentageApproved4 = (countApproved4 * 100) / 10;
        
        double percentageApproved4 = (countApproved4 * 100) / 18357;
        
        System.out.println("Percentage of applicants approved in fourth method: " + percentageApproved4);
        
        int countApproved5 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant5()) {
                countApproved5 = countApproved5 + 1;
            }
        }
        
        System.out.println("\nNumber of applicants approved in fifth method: " + countApproved5);
        
        //double percentageApproved5 = (countApproved5 * 100) / 10;
        
        double percentageApproved5 = (countApproved5 * 100) / 18357;
        
        System.out.println("Percentage of applicants approved in fifth method: " + percentageApproved5);
        
        int countApproved6 = 0;
        for (PositionApplicant app : applicants) {
            if (app.analyze_applicant6()) {
                countApproved6 = countApproved6 + 1;
            }
        }
        
        System.out.println("\nNumber of applicants approved in sixth method: " + countApproved6);
                
        double percentageApproved6 = (countApproved6 * 100) / 18357;
        
        System.out.println("Percentage of applicants approved in sixth method: " + percentageApproved6);
        
     
     //This same description is also included in the PositionApplicant class:
     
     /**
     
     * This evaluation system still prioritizes the grades of the most important classes by requiring an A or higher in them
     * Those three classes are Algorithms, advCompProg, and DataBaseSys
     * Not placing emphasis on Intro to Comp Prog too much as long as they have an A in advCompProg 
     * This is because advCompProg essentially branches off Intro to Comp Prog, and showing an upward trajectory is important
     * A requirement was added for a "threshold" grade in Intro to Comp Prog to narrow down the pool (just passing/C or higher)
     * Requirements were added for Networking as well, because applicants should possess those skills and not just be smart
       (a B+ or higher)
     * A similar requirement was added for Operating Systems, but with a lower requirement (a B+ or higher)
     * With those requirements, about 4 percent of applicants are selected, and since this company is so popular and because
       the applicant pool is so competitive, I think this is a reasonable "acceptance rate"
     * The remaining applicants are below 1000, so now that we have the applicants with a preferable range of grades,
       we can actually engage in a more holistic review to select the best ones
     * Overall, this method is more comprehensive by including requirements for all the classes, and gives a desired range
     * The desired range is about 1-4 percent, or close to 5 percent
     * To get the desired range, I did have to do some trial and error with the scores, but I think these are reasonable
       score ranges and they prioritize the classes/grades required well
    
     **/
    
        
        

    }

}
