/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.transcriptproject;

import java.util.Random;

/**
 *
 * @author zoya
 */
public class TranscriptDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Transcript testTranscript = new Transcript(5);
        System.out.println("The GPA is " + testTranscript.getGPA());

        // Let's build transcripts for a whole bunch of students
        final int NSTUDENTS = 10;
        Transcript[] studentTranscripts = new Transcript[NSTUDENTS];
        Random rand = new Random();

        // we have to build each transcript object
        // we'll use a random number of courses
        for (int i = 0; i < NSTUDENTS; i++) {
            studentTranscripts[i] = new Transcript(rand.nextInt(4) + 3);

        }

        System.out.println("The transcript hash is + "
                + studentTranscripts);

        // Let's build a table of grades
        // We are instatiating this as an array of NSTUDENTS rows
        // but no columns yet
        Grade.Grades[][] studentGrades = new Grade.Grades[NSTUDENTS][];
        // Each Transcripts has a different number of courses, so
        // each row will have a different number of columns
        for (int i = 0; i < NSTUDENTS; i++) {
            int nCourses = studentTranscripts[i].getnCourses();
            // The ith row has nCourses columns
            studentGrades[i] = new Grade.Grades[nCourses];
            // now put the grades in place: The ith students and the ith grade
            for (int j = 0; j < nCourses; j++) {
                studentGrades[i][j] = studentTranscripts[i].getCourses()[j].getGrade();
            }
        }

        // print out the array
        for (int iRow = 0; iRow < NSTUDENTS; iRow++) {
            for (int iColumn = 0; iColumn < studentGrades[iRow].length; iColumn++) {
                Grade.Grades grade = studentGrades[iRow][iColumn];
                System.out.print(grade + "\t");
            }
            System.out.print(studentTranscripts[iRow].getGPA());
            System.out.println();
        }
        
        // Can we change the number of courses in a Transcript object?
        // No -- it's read only, and changing the length of an array is hard
        // Can we change the number of credits in a single course in a transcript?
        Transcript testing = studentTranscripts[0];
        // Change number of credits for a course
        // Get the transcript (it's in testing)
        // Ask the transcript for the course array with getCourses()
        // Ask the array its first Course object at index 0
        // Tell that Courses object to change its number of credits
        testing.getCourses()[0].setCredits(12);
        

    }

}
