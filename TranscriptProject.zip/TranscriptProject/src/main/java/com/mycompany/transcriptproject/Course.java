/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.transcriptproject;

import java.util.Random;

/**
 *
 * @author zoya
 */
public class Course {

    private String name;
    private int number;
    private String instructor;
    private String location;
    private int credits;
    private int seciton;
    private Grade.Grades grade;
    private Random rand = new Random();

    // build a course with a random grade and number of credits
    public Course() {
        grade = Grade.randomGrade();
        credits = rand.nextInt(4) + 1;

    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public String getInstructor() {
        return instructor;
    }

    public String getLocation() {
        return location;
    }

    public int getCredits() {
        return credits;
    }

    public int getSeciton() {
        return seciton;
    }

    public Grade.Grades getGrade() {
        return grade;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public void setSeciton(int seciton) {
        this.seciton = seciton;
    }

    public void setGrade(Grade.Grades grade) {
        this.grade = grade;
    }

}
