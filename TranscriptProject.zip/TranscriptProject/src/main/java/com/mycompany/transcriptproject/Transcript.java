/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.transcriptproject;

/**
 *
 * @author zoya
 */
public class Transcript {

    private Course[] courses;
    private int nCourses;
    private int nCredits;
    private double GPA;

    // Construct a Trancscript object with a number of random Course objects
    public Transcript(int nCourses) {
        this.nCourses = nCourses;
        // now we can instantiate the courses array
        courses = new Course[nCourses];
        // But we also have to instatiate each Course object in the array
        for (int i = 0; i < nCourses; i++) {
            courses[i] = new Course();

        }
        // call a method to calculate the GPA
        calculateGPA();

    }

    // Because the Transcript object should always update its own GPA
    // this method can be private
    private void calculateGPA() {
        GPA = 0;
        nCredits = 0;

        for (int i = 0; i < nCourses; i++) {
            double grade = courses[i].getGrade().getValue();
            int courseCredits = courses[i].getCredits();
            GPA += grade * courseCredits;
            nCredits += courseCredits;
        }

        GPA /= nCredits;
    }

    public Course[] getCourses() {
        return courses;
    }

    public int getnCourses() {
        return nCourses;
    }

    public int getnCredits() {
        return nCredits;
    }

    public double getGPA() {
        return GPA;
    }
}
