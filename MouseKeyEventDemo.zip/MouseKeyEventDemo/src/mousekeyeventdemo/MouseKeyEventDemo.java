package mousekeyeventdemo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class MouseKeyEventDemo extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        MouseKeyPane root = new MouseKeyPane();
        
        Scene scene = new Scene(root, 400, 800);
        
        primaryStage.setTitle("Mouse and Key Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
