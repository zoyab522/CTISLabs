package mousekeyeventdemo;

import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class MouseKeyPane extends Pane {

    private Color squareColor = Color.RED;
    private Rectangle square;
    private Font displayFont;
    private Label displayResult;
    private boolean move = false, drag = false;

    public MouseKeyPane() {

        square = new Rectangle(100, 100, 100, 100);
        square.setFill(squareColor);
        displayResult = new Label("");
        displayResult.setLayoutX(100);
        displayResult.setLayoutY(200);
        getChildren().add(square);
        getChildren().add(displayResult);

        // 5a. Tell the square object that it can be the focus of the keyboard
        // Focus: Which object is responsible at that moment for responding to key events
        square.setFocusTraversable(true);
        // After this line executes, square can gain focus and the program can respond to key events

        displayFont = Font.font("Arial", FontWeight.BOLD, 24);
        displayResult.setFont(displayFont);

        // 5. Connect the event handler to the display element that we want to monitor
        // Because there is no specific element identified, the event handler is connected
        // to the whole MouseKeyPane
        setOnMouseClicked(this::processMouseClick);
        // If we want to turn the square blue only when the cursor enters that square,
        // then we need to connect the enter event handler to the square object
        square.setOnMouseEntered(this::processMouseEnter);
        setOnMouseEntered(this::processMouseEnter);
        setOnMouseExited(this::processMouseExit);
        setOnMouseMoved(this::processMouseMove);
        setOnMouseDragged(this::processMouseDrag);
        setOnMousePressed(this::processMousePress);
        setOnMouseReleased(this::processMouseRelease);
        setOnMouseClicked(this::processMouseClick);

        // 5. Key event are not detected by Pane objects
        // connect each event handler to some object displayed in the Pane
        // In this case, we use the square
        square.setOnKeyPressed(this::processKeyPress);
        square.setOnKeyReleased(this::processKeyRelease);
        square.setOnKeyTyped(this::processKeyType);

    }

    // 4. Write an event handler for clicking for clicking the mouse
    // Each mouse event generatea MouseEvent object
    public void processMouseClick(MouseEvent event) {
        System.out.println("The click event is " + event);
        square.setFill(Color.ORANGE);
        constructDisplay("Mouse clicked");
        // if the user double-clicks, the color is set to violet
        if (event.getClickCount() == 2) {
            square.setFill(Color.VIOLET);
        }
    }

    public void processMousePress(MouseEvent event) {
        square.setFill(Color.GREEN);
        constructDisplay("Mouse pressed");
    }

    public void processMouseRelease(MouseEvent event) {
        square.setFill(Color.RED);
        drag = false;
        constructDisplay("Mouse released");
    }

    public void processMouseDrag(MouseEvent event) {
        if (!drag) {
            constructDisplay("Mouse dragged");
        }
        drag = true;
        if (event.isShiftDown()) {
            // increase the sides of the square by two pixels
            square.setWidth(square.getWidth() + 2);
            square.setHeight(square.getHeight() + 2);
        } else {
            // get the position of the moue cursor during the drag
            // use the getters for x and y of the event object
            double newX = event.getX();
            double newY = event.getY();
            // set the value of x and y for the square to these new values
            square.setX(newX);
            square.setY(newY);

        }

    }

    public void processMouseMove(MouseEvent event) {
        if (!move) {
            constructDisplay("Mouse moved");
            constructDisplay(event.getX() + " " + event.getY());
        }
        move = true;
    }

    public void processMouseEnter(MouseEvent event) {
        square.setFill(Color.BLUE);
        constructDisplay("Mouse enter");
    }

    public void processMouseExit(MouseEvent event) {
        square.setFill(Color.CYAN);
        constructDisplay("Mouse exit");
    }

    public void processKeyPress(KeyEvent event) {
        System.out.println(event);
        constructDisplay("Key press: " + event.getCode());
        if (event.getCode() == KeyCode.ESCAPE) {
            move = false;
            drag = false;
        }
    }
    
    // Write an event handler for when the user releases a key 
    public void processKeyRelease(KeyEvent event) {
        constructDisplay("Key release: " + event.getCode());
        // if the user presses the r key, rotate the square by 5 degrees
        if (event.getCode() == KeyCode.R) {
            square.setRotate(square.getRotate() + 5);
        }
    }

    public void processKeyType(KeyEvent event) {
        constructDisplay("Key typed: " + event.getCharacter());
    }

    public void constructDisplay(String add) {
        displayResult.setText(displayResult.getText() + add + "\n");
        if (displayResult.getHeight() > 500) {
            displayResult.setText("");
        }
    }
    
}
