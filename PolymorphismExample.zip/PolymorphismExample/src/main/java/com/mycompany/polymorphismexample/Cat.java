/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polymorphismexample;

/**
 *
 * @author zoya
 */
public class Cat extends Animal { // extends is a java keyword that is used to implement inheritance

    private String color;

    public Cat(boolean veg, boolean car, boolean omni,
            String food, int legs) {
        super(veg, car, omni, food, legs);
        this.color = "White";
    }

    public Cat(boolean veg, boolean car, boolean omni,
            String food, int legs, String col) {
        super(veg, car, omni, food, legs);
        this.color = col;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void animalSound() {
        System.out.println("Meow Meow");
    }

}
