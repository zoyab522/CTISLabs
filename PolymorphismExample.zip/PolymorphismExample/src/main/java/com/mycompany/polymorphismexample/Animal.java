/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polymorphismexample;

/**
 *
 * @author zoya
 */
public class Animal {

    private boolean vegeterian;
    private boolean carnivore;
    private boolean omnivore;

    private String eats;

    private int numOfLegs;

    public Animal() {
    }

    public Animal(boolean veg, boolean car,
            boolean omni, String food, int legs) {
        this.vegeterian = veg;
        this.omnivore = omni;
        this.carnivore = car;
        this.eats = food;
        this.numOfLegs = legs;

    }

    public boolean isVegeterian() {
        return vegeterian;
    }

    public void setVegeterian(boolean vegeterian) {
        this.vegeterian = vegeterian;
    }

    public void setCarnivore(boolean carnivore) {
        this.carnivore = carnivore;
    }

    public void setOmnivore(boolean omnivore) {
        this.omnivore = omnivore;
    }

    public void setEats(String eats) {
        this.eats = eats;
    }

    public void setNumOfLegs(int numOfLegs) {
        this.numOfLegs = numOfLegs;
    }

    public boolean isCarnivore() {
        return carnivore;
    }

    public boolean isOmnivore() {
        return omnivore;
    }

    public String getEats() {
        return eats;
    }

    public int getNumOfLegs() {
        return numOfLegs;
    }

    @Override
    public String toString() {
        return "Animal{" + "vegeterian=" + vegeterian
                + ", carnivore=" + carnivore
                + ", omnivore=" + omnivore
                + ", eats=" + eats
                + ", numOfLegs="
                + numOfLegs + '}';
    }

    public void animalSound() {
        System.out.println("Inside the animalSound method;");

    }

}
