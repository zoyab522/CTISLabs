/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polymorphismexample;

/**
 *
 * @author zoya
 */
public class Dog extends Animal {
    
    private String color;
    private int weight;
    private String name;
    
    public Dog(boolean veg, boolean car, boolean omni,
            String food, int legs)
    {
        super(veg,  car, omni, food, legs);
        this.color = "brown";
    }
    
    public Dog (boolean veg, boolean car, boolean omni,
            String food, int legs, String col)
    {
        super(veg,  car, omni, food, legs);
        this.color = col; 
    }
    
    public Dog (boolean veg, boolean car, boolean omni,
            String food, int legs, String col, 
            int w, String nam)
    {
        super(veg,  car, omni, food, legs);
        this.color = col; 
        this.weight = w;
        this.name = nam;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public int getWeight() {
        return weight;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Dog{" + "color=" 
                + color + ", weight=" 
                + weight + ", name=" 
                + name + '}';
    }
    
    public void animalSound(){
        System.out.println("Woof Woof");
    }
    
    
}
