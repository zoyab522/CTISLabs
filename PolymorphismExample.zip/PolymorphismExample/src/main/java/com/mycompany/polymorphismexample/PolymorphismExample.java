/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.polymorphismexample;

/**
 *
 * @author zoya
 */
public class PolymorphismExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Testing Animal Sounds:\n");
        
        Animal obj1 = new Dog(false, true, true, "meat", 4);
        obj1.animalSound();
        System.out.println(obj1);
        
        Animal obj2 = new Cat(true, true, true, "various", 4);
        obj2.animalSound();
        System.out.println(obj2);
        
        Cat cat = new Cat(false, true, true, 
                "milk", 4, "black");
        System.out.println("Cat is Vegeterian? " 
                            + cat.isVegeterian());
        System.out.println("Cat eats: " +
                                cat.getEats());
        
        System.out.println("Cat color: " +
                                cat.getColor());
        
        Animal An = new Animal();
        An.animalSound();
        
        Dog doggy = new Dog(false, true, true, "Bones", 4);
        doggy.animalSound();
    }
    
}
