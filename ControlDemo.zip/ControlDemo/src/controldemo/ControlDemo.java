package controldemo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class ControlDemo extends Application {

    @Override
    public void start(Stage primaryStage) {

        // Driver program instantiates the layout pane that we want to put in our scene
        RectanglePane root = new RectanglePane();
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Rectangle");
        primaryStage.setScene(scene);
        primaryStage.show();

        // To add a new windo, first declare and instantiate the Stage
        Stage controlWindow = new Stage();
        // Declare and instantiate a ControlPane object to put in this window
        // and tell that ControlPane that root is the RectanglePane it will control
        ControlPane cPane = new ControlPane(root);
        //Put cPane into a Scene
        Scene cScene = new Scene(cPane, 400, 400);
        //Tell controlWindow what it's Scene object is
        controlWindow.setScene(cScene);
        controlWindow.setTitle("Color picking");
        // Tell controlWindow to display itself
        controlWindow.show();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
