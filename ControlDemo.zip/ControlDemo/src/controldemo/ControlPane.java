package controldemo;

// This displays objects, so it must extend some kind of  layout pane, like FlowPane

import javafx.event.ActionEvent;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;

public class ControlPane extends FlowPane {

    // 1. We're going to declare a ColorPicker attribute
    private ColorPicker picker;
    // Add a RectanglePane attribute to tell this object who it should send messages to
    private RectanglePane theRectanglePane;
    
    // Need an empty constructor to build the pane and instantiate and display the ColorPicker
    // Update the constructor so that this object can be told which RectanglePane it should
    // communicate with
    public ControlPane(RectanglePane theRectanglePane) {
        // Set the value of theRectanglePane attribute
        this.theRectanglePane = theRectanglePane;
        // 2. Instantiate the ColorPicker
        picker = new ColorPicker();
        
        // 3. Add it to the pane for display
        getChildren().add(picker);
    
        // 5. Connect the event handler to the interactive object
        picker.setOnAction(this::processColorPick);
    }
    
    
    // 4. Build an event handler--ColorPicker object generate ActionEvent objects
    public void processColorPick(ActionEvent event) {
        // Get the color that the ColorPicker is set to
        Color theColor = picker.getValue();
        // Send the setSquareColor message to theRectanglePane with this information
        theRectanglePane.setSquareColor(theColor);
    }
            
            
}
