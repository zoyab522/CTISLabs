package controldemo;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class RectanglePane extends Pane {
    // Use Pane because we want to place objects at specified (x,y) coordinates

    // 1. Declare the object
    private Rectangle square;
    private Color squareColor;

    // start with an empty constructor to build the initial drawing
    public RectanglePane() {
        // 2. Instantiate the object
        square = new Rectangle(100, 100, 200, 200);
        squareColor = Color.CORNFLOWERBLUE;
        // 2a. Decorating the object
        square.setFill(squareColor);
        // 3. Displaying the object
        getChildren().add(square);
    }

    public Rectangle getSquare() {
        return square;
    }

    public void setSquare(Rectangle square) {
        this.square = square;
    }

    public Color getSquareColor() {
        return squareColor;
    }

    // Build a setter that can be accessed from ControlPane and both
    // updates squareColor and the fill color for Square
    public void setSquareColor(Color squareColor) {
        // 1. Update the attribute
        this.squareColor = squareColor;
        // 2. Update the color of the square attribute
        square.setFill(squareColor);

    }

}
