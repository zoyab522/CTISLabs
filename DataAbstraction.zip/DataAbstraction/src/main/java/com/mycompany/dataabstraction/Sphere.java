package com.mycompany.dataabstraction;

import java.text.DecimalFormat;


public class Sphere extends Circle {
    
    DecimalFormat fmt = new DecimalFormat("0.##");
    
    public Sphere (String color, double radius) {
        super (color, radius); // calls the circle's constructor which in turn calls the Shape's constructor
        System.out.println("The Sphere constructor is called;");
        this.radius = radius;
        this.dime = dimension.threeDimensional.name();
        
    }

    public DecimalFormat getFmt() {
        return fmt;
    }

    public double getRadius() {
        return radius;
    }

    public String getColor() {
        return color;
    }

    public String getDime() {
        return dime;
    }

    public void setFmt(DecimalFormat fmt) {
        this.fmt = fmt;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setDime(String dime) {
        this.dime = dime;
    }
    
    public double volume() {
        return 4.0/3.0 * Math.PI * Math.pow(radius, 3);
        
    }
    
    public double area() {
        return 4 * Math.PI * Math.pow(radius, 2);
    }
    
    public String toString() {
        System.out.println("Sphere's radius is equal to: " + radius
            + ",\n Sphere's volume is equal to: " + volume()
            + ",\n Sphere's area is equal to: " + area() 
            + ",\n Sphere is " + dime);
        
        return "Sphere's radius is equal to: " + radius
            + ",\n Sphere's volume is equal to: " + fmt.format(this.volume())
            + ",\n Sphere's area is equal to: " + fmt.format(this.area()) 
            + ",\n Sphere is " + dime;
    }
    
    
}
