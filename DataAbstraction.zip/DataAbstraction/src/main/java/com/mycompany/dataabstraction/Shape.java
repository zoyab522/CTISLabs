package com.mycompany.dataabstraction;


abstract class Shape {
    
    String color;
    
    enum dimension {twoDimensional, threeDimensional};
    
    String dime; 
    
    abstract double area(); // area is an abstract method
    abstract double perimeter();
    
    public abstract String toString();
    
    //Note that abstract methods does not need to be developed in the abstract class
    
    
    //Note that an instance of an abstract class cannot be created
    
    //abstract class can have constructor
    
    public Shape (String col) {
        
        System.out.println("The Shape constructor is called;");
        this.color = col;
        
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
    
    static void staticfunc() {
        System.out.println("This static staticfunc method" 
                + " could not be called without instantiating any object");
    }
    
    final void func() {
        System.out.println("This final func method could not be" 
                + " overwritten in any extended method without instantiating a new class");
    }
    
    
}
