/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dataabstraction;

class Rectangle extends Shape {
    
    double length;
    double width;
    
    //An abstract class can contain constructors and a constructor of
    //abstract class is called when an instance of an inherited class is create
    
    public Rectangle (String col, double len, double wid) {
        
        super(col); //calls the abstract class Shape constructor
        
        System.out.println("Rectangle constructor is called");
        this.length = len;
        this.width = wid;
    }
    
    @Override double area() {
        return length * width;
        
    }
    
    @Override double perimeter() {
        return (2 * (length + width));
    }
    
    @Override public String toString() {
        return "Rectangle color is: " + super.getColor()
            + ",\nRectangle area is: " + area()
            + ",\nRectangle perimeter is: " + perimeter()
            + ",\nand Rectangle is: " + dime;

        
    }
   
}


