/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dataabstraction;

class Circle extends Shape {
    
    double radius;
    
    public Circle (String col, double rad) {
        
        // calling a Shape constructor
        
        super(col);
        System.out.println("The Circle constructor is called");
        this.radius=rad;
        this.dime = dimension.twoDimensional.name();
        
    }
    
    @Override double area() {
        
        return Math.PI * (Math.pow(radius, 2));
    }
    
    @Override double perimeter() {
        
        return Math.PI * 2 * radius;
    }
    
    @Override public String toString() {
        
        return "Circle color is: " + super.getColor()
            + ",\n Circle area is: " + area()
            + ",\ncircle perimeter is " + perimeter()
            + ",\nand circle is: " + dime;
        
    }
    
}

