/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.dataabstraction;

/**
 *
 * @author zoya
 * Data abstraction means that only the essential details are displayed to the user
 * Data abstraction may also be defined as the process of identifying only the required characteristics of 
   an object while ignoring the irrelevant details
 * The properties and behaviors of an object differentiate it from other objects of similar type 
   and also help in classifying/grouping the objects.
 */
public class DataAbstractionExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Shape s = new Shape(); gives an error -- cannot have an object of type abstract class
        
        Shape s1 = new Circle ("Red", 5.2);
        Shape s2 = new Rectangle ("Yellow", 5, 7);
        
        System.out.println(s1.toString());
        System.out.println(s2.toString());
        
        s1.func(); // func is a final method in the abstract class Shape
        //func(); error, an object has to call the final method
        
        Shape.staticfunc(); //staticfunc is as the name implies is a static method
        
        Shape Sp = new Sphere("blue", 7.11);
        System.out.println(Sp.toString());
    }
    
}
