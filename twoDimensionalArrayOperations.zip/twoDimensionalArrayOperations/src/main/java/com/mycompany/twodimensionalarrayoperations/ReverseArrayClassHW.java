/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.twodimensionalarrayoperations;

/**
 *
 * @author zoya
 */
public class ReverseArrayClassHW {
    
    static int[][] flipArrayHorizontally(int[][] original){
        int [][] arr = new int[TwoDimArrayHW.x][TwoDimArrayHW.y];
        for(int i = 0; i < TwoDimArrayHW.x; i++) {
            for(int j = 0; j < TwoDimArrayHW.y; j++){
                arr[(TwoDimArrayHW.x - 1) - i][j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] flipArrayVertically(int[][] original){
        int [][] arr = new int[TwoDimArrayHW.x][TwoDimArrayHW.y];
        for(int i = 0; i < TwoDimArrayHW.x; i++){
            for(int j = 0; j < TwoDimArrayHW.y; j++){
                arr[i][(TwoDimArrayHW.y - 1) - j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] reverseArray(int[][] original){     
        int [][] arr = new int[TwoDimArrayHW.x][TwoDimArrayHW.y];
        for(int i = 0; i < TwoDimArrayHW.x; i++){
            for(int j = 0; j < TwoDimArrayHW.y; j++){
                arr[(TwoDimArrayHW.x - 1) - i][(TwoDimArrayHW.y - 1) - j] = original[i][j];
            }
        }
        return arr;
    }
    
    static int[][] reverseTransposeArray(int[][] original) {
        int[][] arr = new int[TwoDimArrayHW.y][TwoDimArrayHW.x];
        for (int i = 0; i < TwoDimArrayHW.y; i++){
            for(int j = 0; j < TwoDimArrayHW.x; j++){
                arr[(TwoDimArrayHW.y - 1) - i][(TwoDimArrayHW.x - 1) - j] = original[j][i];
            }
        }
        return arr;
    }
    
    static int[][] transposeArray(int[][] original){     
        int [][] arr = new int[TwoDimArrayHW.y][TwoDimArrayHW.x];
        for(int i = 0; i < TwoDimArrayHW.y; i++){
            for(int j = 0; j < TwoDimArrayHW.x; j++){
                arr[i][j] = original[j][i];
            }
        }
        return arr;
    }
    
}
