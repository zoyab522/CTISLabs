/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.twodimensionalarrayoperations;

/**
 *
 * @author zoya
 */
public class TwoDimArrayOperationsHW extends ReverseArrayClassHW {
    
    static void printArray(int[][] array) {

        System.out.println("Printing the array:");
        for(int i = 0; i <  TwoDimArrayHW.x; i++) {
            for(int j = 0; j < TwoDimArrayHW.y; j++) {
                System.out.print("[" + i + "][" + j + "] = " 
                        + array[i][j] + "\t");
            } 
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }
    
    static void printArray2(int[][] array) {
        
        System.out.println("Printing the array:");
        for(int i = 0; i < TwoDimArrayHW.y; i++) {
            for(int j = 0; j < TwoDimArrayHW.x; j++) {
                System.out.print("[" + i + "][" + j + "] = " 
                        + array[i][j] + "\t");
            } 
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }
    
    static double getTotal(double[][] array) {
        double total = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++){
            for (int j = 0; j < TwoDimArrayHW.y; j++){
                total += array[i][j];
            }
        }
        return total;
    }
    
    static double getAverage(double[][] array) {
        double total = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            for (int j = 0; j < TwoDimArrayHW.y; j++) {
                total += array[i][j];
            }
        }
        double average = total / (TwoDimArrayHW.x * TwoDimArrayHW.y);
        return average;
    }

    static double getRowTotal(double[][] array, int row) {
        double rowTotal = 0;
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            rowTotal += array[row][j];
        }       
        return rowTotal;
    }
    
    static double getColumnTotal(double[][] array, int col) {
        double columnTotal = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            columnTotal += array[i][col];
        }       
        return columnTotal;
    }
    
    static double getHighestInRow(double[][] array, int row) {
        double highest = array[row][0];
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            if (array[row][j] > highest) {
                highest = array[row][j];
            }
            j++;
        }       
        return highest;
    }
    
    static double getLowestInRow(double[][] array, int row) {
        double lowest = array[row][0];
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            if (array[row][j] < lowest) {
                lowest = array[row][j];
            }
            j++;
        }       
        return lowest;
    }
    
    static int getElementCount(double[][] array) {
        int elementCount = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            for(int j = 0; j < TwoDimArrayHW.y; j++) {
                elementCount++;
            }
        }
        return elementCount;
    }
    
    static int getTotal(int[][] array) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++){
            for (int j = 0; j < TwoDimArrayHW.y; j++){
                total += array[i][j];
            }
        }
        return total;
    }
    
    static int getAverage(int[][] array) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            for (int j = 0; j < TwoDimArrayHW.y; j++) {
                total += array[i][j];
            }
        }
        int average = total / (TwoDimArrayHW.x * TwoDimArrayHW.y);
        return average;
    }

    static int getRowTotal(int[][] array, int row) {
        int rowTotal = 0;
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            rowTotal += array[row][j];
        }       
        return rowTotal;
    }
    
    static int getColumnTotal(int[][] array, int col) {
        int columnTotal = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            columnTotal += array[i][col];
        }       
        return columnTotal;
    }
    
    static int getHighestInRow(int[][] array, int row) {
        int highest = array[row][0];
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            if (array[row][j] > highest) {
                highest = array[row][j];
            }
            j++;
        }       
        return highest;
    }
    
    static int getLowestInRow(int[][] array, int row) {
        int lowest = array[row][0];
        for (int j = 0; j < TwoDimArrayHW.y; j++) {
            if (array[row][j] < lowest) {
                lowest = array[row][j];
            }
            j++;
        }       
        return lowest;
    }
    
    static int getElementCount1(int[][] array) {
        int elementCount = 0;
        for (int i = 0; i < TwoDimArrayHW.x; i++) {
            for(int j = 0; j < TwoDimArrayHW.y; j++) {
                elementCount++;
            }
        }
        return elementCount;
    }
}


