package com.mycompany.twodimensionalarrayoperations;

import java.util.Scanner;

/**
 *
 * @author zoya
 */
public class TwoDimArrayHW extends TwoDimArrayOperationsHW {

    static int x;
    static int y;
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Insert Code here to ask the user to fill out the array
        Scanner scan = new Scanner(System.in);
        
        // Make it so that the program runs not just for a 3 x 5 array, but any array
        // Use a print statement prompting the user to enter an integer for the first dimension
        System.out.println("Please enter the first array dimension");
        
        // Make sure the input is valid
        if(!scan.hasNextInt()){
                        System.out.println("Please enter a valid integer");
                        System.exit(0);
                    } else {
                     // if the input is valid, store it & keep it positive!
                     // If the user enters -1, output will still print 1
                     x = Math.abs(scan.nextInt()); 
                }
              
        // Use a print statement prompting the user to enter an integer for the second dimension
        System.out.println("Please enter the second array dimension");
        
        // Make sure the input is valid
        if(!scan.hasNextInt()){
                        System.out.println("Please enter a valid integer");
                        System.exit(0);
                    } else {
                     // if the input is valid, store it & keep it positive!
                     // If the user enters -1, output will still print 1
                     y = Math.abs(scan.nextInt()); 
                }
        
        // declare twoDimHW to be a 2-dimensional array of integers of x rows and y columns;
        int[][] twoDimHW = new int[x][y];
        
        System.out.println("Please fill out the (" + x + "x" + y + ") array of " 
                + getElementCount1(twoDimHW) + " element(s):");
        
        // loop for rows (use i)
        for(int i = 0; i < x; i++) {
            // loop for columns (used j)
             for(int j = 0; j < y; j++) {
                 System.out.println("Please enter an integer value for twoDimHW["
                 + i + "][" + j + "]: ");
                  
                 // Ensure that the user doesn't enter any invalid characters
                 // Invalid characters include doubles or any letters/symbols
                 // Use !scan.hasNextInt
                 if(!scan.hasNextInt()){
                        System.out.println("Please enter a valid integer");
                        System.exit(0);
                    } else {
                     // if the input is valid, store it & keep it positive!
                     // If the user enters -1, output will still print 1
                     twoDimHW[i][j] = Math.abs(scan.nextInt()); 
                }
            }
        }
      
        // Use printArray method to print the array “twoDimHW”
        printArray(twoDimHW);
        
        // declare numbersReverse to be a 2-dimensional array
        int[][] numbersReverse;
        
        // use flipArrayHorizontally method to fill it out by flipping the “twoDimHW” horizontally;
        numbersReverse = flipArrayHorizontally(twoDimHW);
        
        // Use printArray method to print the array “numbersReverse”
        System.out.println("Flipping the array Horizontally:");
        printArray(numbersReverse);

        // declare flipArrVer to be a 2-dimensional array
        int[][] flipArrVer;
        
        // use flipArrayVertically method to fill it out by flipping the “twoDimHW” vertically;
        flipArrVer = flipArrayVertically(twoDimHW);
        
        // Use printArray method to print the array “flipArrVer”
        System.out.println("Flipping the array vertically:");
        printArray(flipArrVer);

        // declare reverseArr to be a 2-dimensional array 
        int[][] reverseArr;
        
        // use reverseArray method to fill it out by reversing the “twoDimHW”;
        reverseArr = reverseArray(twoDimHW);
        
        // Use printArray method to print the array “reverseArr”
        System.out.println("Reversing the array:");
        printArray(reverseArr);
       
        // declare transpArr to be a 2-dimensional array
        int[][] transpArr;
        
        // use transposeArray method to fill it out by transposing the “twoDimHW”;
        transpArr = transposeArray(twoDimHW);
        
        // Use printArray method to print the array “transposeArray”
        System.out.println("Transposing the array:");
        printArray2(transpArr);
        
        // declare reverseTranspArr to be a 2-dimensional array 
        int[][] reverseTranspArr;
        
        // use reverseTransposeArray method to fill it out by reversing and transposing the “twoDimHW”;
        reverseTranspArr = reverseTransposeArray(twoDimHW);
        
        // Use printArray method to print the array “reverseTranspArr”
        System.out.println("Reversing and transposing the array:");
        printArray2(reverseTranspArr);

        // Use printArray method to print the array “twoDimHW”
        printArray(twoDimHW);

        // Apply the getTotal method on the “twoDimHW” array
        System.out.println("Total of twoDimHW: " + getTotal(twoDimHW));
        
        // Apply the getAverage method on the “twoDimHW” array
        System.out.println("Average of twoDimHW: " + getAverage(twoDimHW));
        //System.out.println("Average of twoDimHW: " + (getTotal(twoDimHW) / (getElementCount1(twoDimHW))));
        
        // Apply the getRowTotal method on row 0 of the “twoDimHW” array
        System.out.println("Total of row 0 of twoDimHW: " + getRowTotal(twoDimHW, 0));
        
        // Apply the getRowTotal method on row 1 of the “twoDimHW” array
        // Fix error if the user enters an array that is too short (ex: 1x1 array or 2x2 array))
        
        try {
            int rowTotalOne = getRowTotal(twoDimHW, 1);
            System.out.println("Total of row 1 of twoDimHW: " + rowTotalOne);
        } catch(Exception tooSmall){
            System.out.println("Total of row 1 of twoDimHW: NO ROW 1 AVAILABLE "
                    + "-- ARRAY TOO SHORT");
        }        
        
        // Apply the getColumnTotal method on column 0 of the “twoDimHW” array
        System.out.println("Total of col 0 of twoDimHW: " + getColumnTotal(twoDimHW, 0));
        
        // Apply the getColumnTotal method on column 2 of the “twoDimHW” array 
        // Fix error if the user enters an array that is too short (ex: 1x1 array or 2x2 array)
        try {
            int columnTotalTwo = getColumnTotal(twoDimHW, 2);
            System.out.println("Total of column 2 of twoDimHW: " + columnTotalTwo);
        } catch(Exception tooSmall){
            System.out.println("Total of column 2 of twoDimHW: NO COLUMN 2 AVAILABLE "
                    + "-- ARRAY TOO SHORT");
        }       
        
        // Apply the getHighestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Highest in row 0 of twoDimHW: " + getHighestInRow(twoDimHW, 0));
        
        // Apply the getHighestInRow method on row 1 of the “twoDimHW” array
        // Fix error if the user enters an array that is too short (ex: 1x1 array or 2x2 array)        
        try {
            int highestInRowOne = getHighestInRow(twoDimHW, 1);
            System.out.println("Highest in row 1 of twoDimHW: " + highestInRowOne); 
        } catch(Exception tooSmall){
            System.out.println("Highest in row 1 of twoDimHW: NO ROW 1 AVAILABLE "
                    + "-- ARRAY TOO SHORT");
        } 
        
        // Apply the getLowestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Lowest in row 0 of twoDimHW: " + getLowestInRow(twoDimHW, 0));
        
        // Apply the getLowestInRow method on row 1 of the “twoDimHW” array
        // Fix error if the user enters an array that is too short (ex: 1x1 array or 2x2 array)
        
        try{
            int lowestInRowOne = getLowestInRow(twoDimHW, 1);
            System.out.println("Lowest in row 1 of twoDimHW: " + lowestInRowOne);
        }
        catch(Exception tooSmall){
            System.out.println("Lowest in row 1 of twoDimHW: NO ROW 1 AVAILABLE -- ARRAY TOO SHORT");
        } 
        
        // TEST GET ELEMENT COUNT
        // Element Count Works
        //System.out.println("Element Count: " + getElementCount1(twoDimHW));
    }  
}
