package com.mycompany.mp1.strongpasswordgenerator;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import java.util.Scanner;

public class StrongPasswordGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, NoSuchAlgorithmException {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        System.out.println("Please enter your first name: ");
        String firstName;
        firstName = input.next(); // input is stored

        System.out.println("Please enter your last name: ");
        String lastName;
        lastName = input.next();

        System.out.println("Please enter your middle initial: ");
        char middleInitial;
        middleInitial = input.next().charAt(0);
        // we only want the first initial regardless of the input

        System.out.println("Please enter your 2-digits favorite number: ");
        int favoriteNumber;
        favoriteNumber = input.nextInt(); // stores the integer

        System.out.println("Please enter your City of Birth: ");
        String birthCity;
        birthCity = input.next();

        System.out.println("Please enter your favorite color: ");
        String favoriteColor;
        favoriteColor = input.next();

        // print out the random number
        int randNo = rand.nextInt(90) + 10;
        //random 2-digit number from 0 to 99

        System.out.println("Your two-digits random number: " + randNo);

        // FORMATTING INPUTS ---------------------------------------------------
        // FIRST NAME 
        int first = firstName.length();

        String firstLetter = firstName.substring(0, 1);
        String restOfName = firstName.substring(1, first);

        String firstUppercase = firstLetter.toUpperCase();
        String firstLowercase = restOfName.toLowerCase();

        String firstNameFormatted = firstUppercase + firstLowercase;

        // LAST NAME
        int last = lastName.length();

        String lastU = lastName.substring(0, 1);
        String restOfLast = lastName.substring(1, last);

        String lastUppercase = lastU.toUpperCase();
        String lastLowercase = restOfLast.toLowerCase();

        String lastNameFormatted = lastUppercase + lastLowercase;

        // FORMAT MIDDLE INITIAL
        // (a) we only want the middle initial (a single character) and
        // (b) we want the middle initial to be uppercase
        char middleInitialFormatted = Character.toUpperCase(middleInitial);

        // PRINT FULL NAME IN PROPER FORMAT
        System.out.println("Your full name in the correct format is: "
                + firstNameFormatted + " "
                + middleInitialFormatted + ". "
                + lastNameFormatted);

        // EMAIL FORMAT
        // with the email, we want to make everything lowercase: 
        String lastNameEmail = lastNameFormatted.toLowerCase();
        String firstInitEmail = firstUppercase.toLowerCase();
        char middleInitEmail = Character.toLowerCase(middleInitial);

        // PRINT FULL EMAIL IN PROPER FORMAT
        System.out.println("Your email at Guilford in the correct format is: "
                + lastNameEmail + firstInitEmail + middleInitEmail
                + "@guilford.edu");

        // FORMAT BIRTH CITY INPUT
        int city = birthCity.length();
        String firstCity = birthCity.substring(0, 1);
        String restOfCity = birthCity.substring(1, city);
        String firstCityUppercase = firstCity.toUpperCase();
        String CityLowercase = restOfCity.toLowerCase();
        String birthCityFormatted = firstCityUppercase + CityLowercase;
        //System.out.println("Testing city output: " + birthCityFormatted);

        // FORMAT FAVORITE COLOR INPUT
        int color = favoriteColor.length();
        String firstColor = favoriteColor.substring(0, 1);
        String restOfColor = favoriteColor.substring(1, color);
        String firstColorUppercase = firstColor.toUpperCase();
        String colorLowerCase = restOfColor.toLowerCase();
        String colorFormatted = firstColorUppercase + colorLowerCase;
        //System.out.println("Testing color output: " + colorFormatted);

        // FINAL PASSWORD
        /* testing a loop to separate the digits of favorite number
        
        while (favoriteNumber > 0) 
        {
            System.out.println(favoriteNumber % 10);
            favoriteNumber = favoriteNumber / 10;
        }
         */
        String password = firstNameFormatted.substring(0, 2)
                + lastNameFormatted.substring(0, 2)
                + (favoriteNumber / 10)
                + "^" // now we have the '^' symbol between digits of fav number
                + (favoriteNumber % 10)
                + birthCityFormatted.substring(0, 2)
                + colorFormatted.substring(0, 2)
                + randNo;

        System.out.println("Your Final Pwd is: " + password);

        // FINAL PASSWORD HASH
        MessageDigest sha = null;

        byte[] pwdHash = password.getBytes("UTF-8");
        sha = MessageDigest.getInstance("SHA-1");

        pwdHash = sha.digest(pwdHash);

        // PRINT FINAL PASSWORD HASH
        System.out.println("Your Final Pwd hash is: " + pwdHash);

        // PRINT FINAL PASSWORD
        System.out.println("Your password is : ");
        System.out.println("\t" + password);

        // in order to encrypt and decrypt the generated password: 
        //----------------------------------------------------------------------
        final String secretKey = "ThisIsSecretKey";
        String encryptedString = AES.encrypt(password, secretKey);
        String decryptedString = AES.decrypt(encryptedString, secretKey);
        //----------------------------------------------------------------------

        // PRINT ENCRYPTED AND DECRYPTED PASSWORD USING AES AND SECRET KEY
        System.out.println("Your password encrypted using AES and secret key ("
                + secretKey + ") is: ");
        System.out.println("\t" + encryptedString);

        System.out.println("Your password decrypted using AES and secret key ("
                + secretKey + ") is: ");
        System.out.println("\t" + decryptedString);

        // SAYINGS ABOUT PASSWORDS
        System.out.println("Here's some sayings about passwords: ");
        System.out.println("Choosing a hard-to-guess, but easy-to-remember "
                + "password is important!");
        System.out.println("Treat your password like your toothbrush. ");
        System.out.println("Don't let anybody else use it, and get a new one "
                + "every six months.");
        

    }

}
