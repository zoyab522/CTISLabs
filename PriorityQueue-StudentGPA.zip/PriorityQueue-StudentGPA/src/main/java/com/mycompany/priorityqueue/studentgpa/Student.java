/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.priorityqueue.studentgpa;

/**
 *
 * @author zoya
 */
public class Student implements Comparable<Student> {

    public String name;
    public String GNumber;
    public double gpa;

    public Student(String name, String GNumber, double gpa) {
        this.name = name;
        this.GNumber = GNumber;
        this.gpa = gpa;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGNumber(String GNumber) {
        this.GNumber = GNumber;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public String getName() {
        return name;
    }

    public String getGNumber() {
        return GNumber;
    }

    public double getGpa() {
        return gpa;
    }

    @Override
    public String toString() {
        return "Student{" + "name= " + name
                + ", GNumber= " + GNumber
                + ", gpa= " + gpa + '}';
    }

    public int compareTo(Student S) {
        System.out.println("Calling the compareTo() method");
        return S.getGpa() > this.gpa ? 1 : -1;
    }

}
