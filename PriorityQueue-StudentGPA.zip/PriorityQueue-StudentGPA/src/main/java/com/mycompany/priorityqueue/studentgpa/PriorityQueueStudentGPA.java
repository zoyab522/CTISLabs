/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.priorityqueue.studentgpa;

import java.util.PriorityQueue;
import java.util.Iterator;

/**
 *
 * @author zoya
 */
public class PriorityQueueStudentGPA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Creating priority queue constructor having
        //initial capacity of 5
        PriorityQueue<Student> PQ = new PriorityQueue<Student>(5);

        Student student1 = new Student("Tom", "G00556677",
                3.2);
        Student student2 = new Student("Jerry", "G00221133",
                3.6);
        Student student3 = new Student("Tim", "G00112233",
                4.2);
        Student student4 = new Student("Tammy", "G00443322",
                3.4);

        PQ.add(student1);
        PQ.add(student2);
        PQ.add(student3);
        PQ.add(student4);

        System.out.println("Students: ");
        for (Student stud : PQ) {
            System.out.println(stud);
        }

        System.out.println("Students served in their"
                + " priority order: ");
        Iterator iterator = PQ.iterator();

        while (iterator.hasNext()) {
            System.out.print(iterator.next() + "\n");
        }

        System.out.println("Processing Students in their"
                + " priority order (higher GPA first): ");
        while (!PQ.isEmpty()) {
            System.out.println(PQ.poll().getName());
        }
    }

}
