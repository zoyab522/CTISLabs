package booleanexpression;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class QuestionPane extends VBox {

    private float a, b, c;
    private Label aLabel, bLabel, cLabel;
    private TextField aValue, bValue, cValue;
    private Label expr1, expr2, expr3, expr4, expr5; //for expression 5
    private boolean result1, result2, result3, result4, result5; //added result for expression 5
    private Button updateButton;

    private void checkExpressions() {
        //Lab 14: For each statement, replace the keyword true with the correct logical expression

        // (a is less than or equal to c) or (a is less than or equal to b)
        result1 = (a <= c) || (a <= b);
        // b is not less than or equal to c
        result2 = !(b <= c);
        // the sum of a and b is greater than c
        result3 = ((a + b) > c);
        // the product of a and b is less than or equal to 100
        result4 = ((a * b) <= 100);
        //Optional: Add another logical expression to the displayed list
        //the product of a and c is greater than or equal to 50
        result5 = ((a * c) >= 50);
    }

    public QuestionPane() {
        setSpacing(5);
        Font labelFont = Font.font("Arial", 20); 
        a = 3;
        b = 4;
        c = 5;
        aLabel = new Label("a :");
        bLabel = new Label("b :");
        cLabel = new Label("c :");
        aValue = new TextField("" + a);
        bValue = new TextField("" + b);
        cValue = new TextField("" + c);
        
        aLabel.setFont(labelFont);
        bLabel.setFont(labelFont);
        cLabel.setFont(labelFont);
        aValue.setFont(labelFont);
        bValue.setFont(labelFont);
        cValue.setFont(labelFont);
        
        aValue.setPrefColumnCount(6);
        bValue.setPrefColumnCount(6);
        cValue.setPrefColumnCount(6);
        aValue.setAlignment(Pos.CENTER);
        bValue.setAlignment(Pos.CENTER);
        cValue.setAlignment(Pos.CENTER);
        expr1 = new Label();
        expr2 = new Label();
        expr3 = new Label();
        expr4 = new Label();
        expr5 = new Label();//added expression 5
        expr1.setFont(labelFont);
        expr2.setFont(labelFont);
        expr3.setFont(labelFont);
        expr4.setFont(labelFont);
        expr5.setFont(labelFont);
        updateButton = new Button("Update!");
        updateButton.setOnAction(this::userButtonPress);
//		updateButton.addActionListener(new ButtonListener());
        HBox valueBox = new HBox(5);
        valueBox.getChildren().add(aLabel);
        valueBox.getChildren().add(aValue);
        valueBox.getChildren().add(bLabel);
        valueBox.getChildren().add(bValue);
        valueBox.getChildren().add(cLabel);
        valueBox.getChildren().add(cValue);
        valueBox.getChildren().add(updateButton);
        getChildren().add(valueBox);
        getChildren().add(expr1);
        getChildren().add(expr2);
        getChildren().add(expr3);
        getChildren().add(expr4);
        getChildren().add(expr5); //getChildren line for expression 5
        checkExpressions();
        constructLabel();

    }

    private void constructLabel() {
        a = Float.parseFloat(aValue.getText());
        b = Float.parseFloat(bValue.getText());
        c = Float.parseFloat(cValue.getText());
        checkExpressions();
        expr1.setText("(a is less than or equal to c) or (a is less than or equal to b) evaluates to " + result1);
        expr2.setText("b is not less than or equal to c evaluates to " + result2);
        expr3.setText("the sum of a and b is greater than c evaluates to " + result3);
        expr4.setText("the product of a and b is less than or equal to 100 evaluates to " + result4);
        expr5.setText("the product of a and c is greater than or equal to 100 evaluates to " + result5); //for expression 5
    }

    public void userButtonPress(ActionEvent e) {
        constructLabel();
    }

}
