package booleanexpression;

import java.util.ArrayList;
import java.util.Arrays;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.InputEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class LogicalPane extends VBox {

    private Button evaluate1Button;
    private Label expression;
    private TextField value1Field;
    private TextField value2Field;
    private ComboBox<String> operatorMenu;
    private String currentOperator;
    private boolean result;
    private String output;
    private float aValue;
    private float bValue;
    private ExpressionPane comboResult;

    public LogicalPane(String value1, String value2) {
        String[] operators = {"<", ">", "<=", ">=", "==", "!="};
        ArrayList<String> operatorList = new ArrayList(Arrays.asList(operators));
        ObservableList<String> options = FXCollections.observableArrayList(operatorList);
        currentOperator = operators[0];
        setSpacing(5);
        Font labelFont = Font.font("Arial", 20);
        evaluate1Button = new Button("Evaluate!");
        value1Field = new TextField(value1);
        value1Field.setPrefColumnCount(5);
        value1Field.setAlignment(Pos.CENTER_RIGHT);
        value2Field = new TextField(value2);
        value2Field.setPrefColumnCount(5);
        value2Field.setAlignment(Pos.CENTER_RIGHT);

        value1Field.setFont(labelFont);
        value2Field.setFont(labelFont);
        
        value1Field.setOnAction(this::userReturnPress);
        value2Field.setOnAction(this::userReturnPress);
//        value1Field.set(this::userChangedValue);
        ChangeListener cListener = new ValueListener();
        value1Field.textProperty().addListener(cListener);
        value2Field.textProperty().addListener(cListener);

        operatorMenu = new ComboBox(options);
        operatorMenu.setOnAction(this::selectMenuItem);
        operatorMenu.getSelectionModel().select(0);

        expression = new Label();
        expression.setFont(labelFont);
        
        setOutput();
        constructLabel(value1Field, value2Field, currentOperator, expression);

        HBox expressionBox = new HBox(5);
        expressionBox.getChildren().add(value1Field);
        expressionBox.getChildren().add(operatorMenu);
        expressionBox.getChildren().add(value2Field);
        expressionBox.getChildren().add(evaluate1Button);
        getChildren().add(expressionBox);
        getChildren().add(expression);
    }

    private boolean checkExpression(float value1, float value2, String operator) {
        if (operator.equals("<")) {
            return result = value1 < value2;
        } else if (operator.equals(">")) {
            return result = value1 > value2;
        } else if (operator.equals("<=")) {
            return result = value1 <= value2;
        } else if (operator.equals(">=")) {
            return result = value1 >= value2;
        } else if (operator.equals("!=")) {
            return result = value1 != value2;
        } else {
            return result = value1 == value2;
        }
    }

    public void setComboResult(ExpressionPane comboResult) {
        this.comboResult = comboResult;
    }

    private void constructLabel(TextField aValueField, TextField bValueField, String operator, Label label) {
        aValue = Float.parseFloat(aValueField.getText());
        bValue = Float.parseFloat(bValueField.getText());
        boolean result = checkExpression(aValue, bValue, operator);
        setOutput();
        label.setText("The result of " + getOutput() + " is " + result);

    }

    public boolean getResult() {
        return result;
    }

    private void setOutput() {
        output = aValue + " " + currentOperator + " " + bValue;
    }

    public String getOutput() {
        return output;
    }

    public void selectMenuItem(ActionEvent e) {
        ComboBox cb = (ComboBox) e.getSource();
        currentOperator = (String) cb.getValue();
        updateResults();
    }

    public void userReturnPress(ActionEvent e) {
        updateResults();

    }

    private class ValueListener implements ChangeListener {

        @Override
        public void changed(ObservableValue observable, Object oldValue, Object newValue) {
            String value = (String) newValue;
            if (value.length() > 0) {
                updateResults();
            }

        }

    }

    public void updateResults() {
        constructLabel(value1Field, value2Field, currentOperator, expression);
        setOutput();
        comboResult.update();

    }

}
