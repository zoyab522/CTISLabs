package booleanexpression;

import java.util.ArrayList;
import java.util.Arrays;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class ExpressionPane extends VBox {

    private LogicalPane panel1;
    private LogicalPane panel2;
    private String expression1;
    private String expression2;
    private Label expression;
    private Label negExpression;
    private Label value1Field;
    private Label value2Field;
    private ComboBox<String> operatorMenu;
    private String currentOperator;
    private boolean result;

    public ExpressionPane(LogicalPane panel1, LogicalPane panel2) {
        String operators[] = {"&&", "||"};
        ArrayList<String> operatorList = new ArrayList(Arrays.asList(operators));
        ObservableList<String> options = FXCollections.observableArrayList(operatorList);
        currentOperator = operators[0];
        setSpacing(5);
        this.panel1 = panel1;
        this.panel2 = panel2;

        Font labelFont = Font.font("Arial", 20);
        value1Field = new Label();
        value2Field = new Label();
        expression = new Label();
        negExpression = new Label();
        value1Field.setFont(labelFont);
        value2Field.setFont(labelFont);
        expression.setFont(labelFont);
        negExpression.setFont(labelFont);
        update();
        operatorMenu = new ComboBox(options);
        operatorMenu.setOnAction(this::selectMenuItem);
        operatorMenu.getSelectionModel().select(0);
        HBox expressionBox = new HBox(5);
        expressionBox.getChildren().add(value1Field);
        expressionBox.getChildren().add(operatorMenu);
        expressionBox.getChildren().add(value2Field);
        getChildren().add(expressionBox);
        getChildren().add(expression);
        getChildren().add(negExpression);

    }

    private boolean checkExpression(boolean value1, boolean value2, String operator) {
        if (operator.equals("&&")) {
            return result = value1 && value2;
        } else {
            return result = value1 || value2;
        }
    }

    private void constructLabel() {
        String expressionValue = value1Field.getText()
                + " " + currentOperator + " " + value2Field.getText();
        boolean result = checkExpression(panel1.getResult(), panel2.getResult(), currentOperator);
        expression.setText("The result of " + expressionValue + " is " + result);
        negExpression.setText("The result of !(" + expressionValue + ") is " + !result);
    }

    public void update() {
        expression1 = panel1.getOutput();
        expression2 = panel2.getOutput();

        value1Field.setText("(" + expression1 + ")");
        value2Field.setText("(" + expression2 + ")");
        constructLabel();
    }

    public void selectMenuItem(ActionEvent e) {
        ComboBox cb = (ComboBox) e.getSource();
        currentOperator = (String) cb.getValue();
        constructLabel();
    }

}
