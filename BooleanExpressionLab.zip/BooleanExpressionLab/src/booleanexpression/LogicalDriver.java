package booleanexpression;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LogicalDriver extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        LogicalPane panel1 = new LogicalPane("3", "5");
        LogicalPane panel2 = new LogicalPane("6", "4");
        ExpressionPane panel3 = new ExpressionPane(panel1, panel2);
        panel1.setComboResult(panel3);
        panel2.setComboResult(panel3);
        QuestionPane panel4 = new QuestionPane();

        VBox root = new VBox(40);
        root.setPadding(new Insets(10, 10, 10, 10));


        root.getChildren().add(panel1);
        root.getChildren().add(panel2);
        root.getChildren().add(panel3);
        root.getChildren().add(panel4);

        Scene mainScene = new Scene(root, 800, 650);

        primaryStage.setScene(mainScene);
        primaryStage.setTitle("Logical Expressions");
        primaryStage.show();
    }

}
