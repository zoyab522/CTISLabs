package animationdemo;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class AnimationDemo extends Application {

    // Make root an attribute so that each Thread can access it
    private MovingCirclePane root;

    @Override
    public void start(Stage primaryStage) {

        MovingCirclePane root = new MovingCirclePane();

        // Start the animation--doesn't work because it hangs the program in an infinite loop
        //root.go();
        // Instantiate a thread that runs the Task
        Thread th = new Thread(new MyTask());
        th.setDaemon(true); // a little trick so that the programe exits completely when we close the window
        th.start();

        Scene scene = new Scene(root, 1000, 800);

        primaryStage.setTitle("Moving Circles");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    // Build a Task object from a Task class that we can ask a new Thread to run
    // That task will execute root.go
    private class MyTask extends Task<Void> {

        @Override
        protected Void call() throws Exception {
            // call refers to what we want this Task to do when the Thread invokes it
            root.go();
            return null;
        }

    }

}
