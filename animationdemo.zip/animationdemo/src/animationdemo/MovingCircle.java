package animationdemo;

import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

// MovingCircle does everything Circle does
// plus it knows its speed and its fill color
public class MovingCircle extends Circle {
    
    private int dx;
    private int dy;
    private Random rand = new Random();
    private Color circleColor;

    // Tell the MovingCircle its position and radius
    public MovingCircle(double centerX, double centerY, double radius) {
        // super means that the Circle constructor is responsible for setting these values
        super(centerX, centerY, radius);
        dx = rand.nextInt(13) - 6;
        dy = rand.nextInt(13) - 6;
        int red = rand.nextInt(256);
        int green = rand.nextInt(256);
        int blue = rand.nextInt(256);
        setFill(circleColor);
        double opacity = rand.nextDouble() * 0.5 + 0.5;
        circleColor = Color.rgb(red, green, blue, opacity);
        setFill(circleColor);
    }
    
    
    public Color getCircleColor() {
        return circleColor;
    }

    public void setCircleColor(Color circleColor) {
        this.circleColor = circleColor;
    }

    public int getDx() {
        return dx;
    }

    public void setDx(int dx) {
        this.dx = dx;
    }

    public int getDy() {
        return dy;
    }

    public void setDy(int dy) {
        this.dy = dy;
    }
    
    
}
