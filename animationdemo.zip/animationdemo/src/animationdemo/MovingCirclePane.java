package animationdemo;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class MovingCirclePane extends Pane {

    // We're going to build an ArrayList of MovingCircle objects as an attribute
    private ArrayList<MovingCircle> theCircles;
    // Declare a ghost Circle object
    private Circle ghostCircle;
    private double xCircle;
    private double yCircle;
    private double radius;

    public MovingCirclePane() {
        // all we'll need here to start are the connections to the mouse event handlers
        // and an instantiation of theCircles
        theCircles = new ArrayList<MovingCircle>();

        // Instantiate the ghost circle
        ghostCircle = new Circle();
        ghostCircle.setVisible(false);
        ghostCircle.setFill(null); // no fill color
        ghostCircle.setStroke(Color.BLUE);
        ghostCircle.setStrokeWidth(3);
        getChildren().add(ghostCircle);

        setOnMouseClicked(this::processMousePress);
        setOnMouseDragged(this::processMouseDrag);
        setOnMouseReleased(this::processMouseRelease);

    }

    // start building a method that will control the animation
    public void go() {
        // this should be an infinite loop so that the circles keep moving
        while (true) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                Logger.getLogger(MovingCirclePane.class.getName()).log(Level.SEVERE, null, ex);
            }
            //System.out.println("Testing");
            // Loop over all MovingCircle objects and change their centerX and CenterY by their dx and dy
            for (MovingCircle mCircle : theCircles) {
                if (mCircle.getCenterX() > getWidth() || mCircle.getCenterX() < 0) {
                    mCircle.setDx(-mCircle.getDx());
                }
                if (mCircle.getCenterY() > getHeight() || mCircle.getCenterY() < 0) {
                    mCircle.setDy(-mCircle.getDy());
                }
                // calculate a new CenterX and centerY
                double newCenterX = mCircle.getCenterX() + mCircle.getDx();
                double newCenterY = mCircle.getCenterY() + mCircle.getDy();
                mCircle.setCenterX(newCenterX);
                mCircle.setCenterY(newCenterY);
            }
        }
    }

    // event handlers for mouse press, drag, and release
    public void processMousePress(MouseEvent event) {
        // establishes the center of the circle
        xCircle = event.getX();
        yCircle = event.getY();
        ghostCircle.setCenterX(xCircle);
        ghostCircle.setCenterY(yCircle);

    }

    public void processMouseDrag(MouseEvent event) {
        // allows the user to drag out the radius
        double xNew = event.getX();
        double yNew = event.getY();
        radius = Math.sqrt(Math.pow(xNew - xCircle, 2) + Math.pow(yNew - yCircle, 2));
        ghostCircle.setRadius(radius);
        ghostCircle.setVisible(true);
    }

    public void processMouseRelease(MouseEvent event) {
        // draws a final cicle in a random color and adds it to the ArrayList
        ghostCircle.setVisible(false);
        MovingCircle theCircle = new MovingCircle(xCircle, yCircle, radius);
        getChildren().add(theCircle);
        theCircles.add(theCircle);
    }
}
