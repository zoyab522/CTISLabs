/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oop_mobiledevice;

import java.util.Date;

/**
 *
 * @author zoya
 */
abstract class Mobile {

    private String manufacturer;
    private String Operating_system;
    private String model;
    private double cost;

    private String SIMCard;
    private String Processor;
    private int InternalMemorySize;
    private boolean IsSingleSIM;
    private Date ManufacturingDate;

    // Constructor
    Mobile(String man, String OS, String mod, double c) {
        this.manufacturer = man;
        this.Operating_system = OS;
        this.model = mod;
        this.cost = c;
    }

    public Mobile(String manufacturer, String Operating_system, String model, double cost, String SIMCard, String Processor, int InternalMemorySize, boolean IsSingleSIM, Date ManufacturingDate) {
        this.manufacturer = manufacturer;
        this.Operating_system = Operating_system;
        this.model = model;
        this.cost = cost;
        this.SIMCard = SIMCard;
        this.Processor = Processor;
        this.InternalMemorySize = InternalMemorySize;
        this.IsSingleSIM = IsSingleSIM;
        this.ManufacturingDate = ManufacturingDate;
    }

    public abstract void dialNumber();

    public abstract String toString();

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void setOperating_system(String Operating_system) {
        this.Operating_system = Operating_system;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setSIMCard(String SIMCard) {
        this.SIMCard = SIMCard;
    }

    public void setProcessor(String Processor) {
        this.Processor = Processor;
    }

    public void setInternalMemorySize(int InternalMemorySize) {
        this.InternalMemorySize = InternalMemorySize;
    }

    public void setIsSingleSIM(boolean IsSingleSIM) {
        this.IsSingleSIM = IsSingleSIM;
    }

    public void setManufacturingDate(Date ManufacturingDate) {
        this.ManufacturingDate = ManufacturingDate;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getOperating_system() {
        return Operating_system;
    }

    public String getModel() {
        return model;
    }

    public double getCost() {
        return cost;
    }

    public String getSIMCard() {
        return SIMCard;
    }

    public String getProcessor() {
        return Processor;
    }

    public int getInternalMemorySize() {
        return InternalMemorySize;
    }

    public boolean isIsSingleSIM() {
        return IsSingleSIM;
    }

    public Date getManufacturingDate() {
        return ManufacturingDate;
    }

}
