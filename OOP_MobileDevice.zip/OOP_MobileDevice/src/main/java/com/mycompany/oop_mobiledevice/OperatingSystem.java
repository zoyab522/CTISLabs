/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.oop_mobiledevice;

/**
 *
 * @author zoya
 */
public enum OperatingSystem {
    Android, iOS, Windows, HarmonyOS, Symbian, SelfDeveloped
    
}


