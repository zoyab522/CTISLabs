/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oop_mobiledevice;

/**
 *
 * @author zoya
 */
public class AndroidMobileDevice extends Mobile {

    public AndroidMobileDevice(String man, String mod, double c) {
        super(man, OperatingSystem.Android.name(),
                mod, c);
    }

    @Override
    public void dialNumber() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String toString() {
        System.out.println("This is an Android mobile device");
        return "Android Mobile Device";
    }

}
