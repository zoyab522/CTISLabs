package creativespace;

/**
 * @authors Taylor and Zoya 
 * FINAL VERSION
 * Sources:
 * https://docs.oracle.com/javase/8/javafx/api/javafx/scene/canvas/GraphicsContext.html#beginPath--
 * https://docs.oracle.com/javafx/2/canvas/jfxpub-canvas.htm
 * https://gist.github.com/abdelaziz321/e9932bd15e4b263c3dae08644c61600c
 * https://docs.oracle.com/javafx/2/api/javafx/scene/paint/Color.html
 * https://www3.ntu.edu.sg/home/ehchua/programming/java/J4b_CustomGraphics.html
 * https://gist.github.com/IAmLuisJ/5985afed66e5b62601a6a73eb8287876
 * We used some of these for the adding image function, and also for part of the logic in drawing shapes/lines
 * We significantly extended and rewrote code that we referenced for this project
 * Major extensions include the undo/redo functions, the clear all function, and the adding/removing layers function
 **/

// These are imports we used for the adding images function
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

// Used for stackpane, undo, redo, and layers
import java.util.ArrayList; 
import java.util.Stack;

// Used for Slider
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

// Used for buttons
// We used Graphics Context to add elements to the Canvas
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton; // Toggle Buttons were used largely for the toolbar/sidebar
import javafx.scene.control.ToggleGroup; 
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane; 
import javafx.scene.layout.HBox; 
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox; // All the tools are in a VBox
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Sidebar extends FlowPane {

    private ToggleButton DrawButton;
    private ToggleButton RectangleButton;
    private ToggleButton CircleButton;
    private ToggleButton EllipseButton;
    private ToggleButton LineButton;
    private ToggleButton EraserButton;
    private ToggleButton OpenButton;
    private ToggleButton ClearAll;
    private ToggleGroup Buttons;
    private ColorPicker Stroke;
    private ColorPicker Fill;
    private Rectangle rectangle;
    private Circle circle;
    private Ellipse ellipse;
    private Line line;
    private boolean drag = false;
    private ArrayList<Stack<Canvas>> layers;
    private Stack<Canvas> undoHistory;
    private Button undoButton;
    private Button redoButton;
    private Button removeLayer;
    private Button addLayer;
    private VBox Tools;
    private HBox tools1;
    private StackPane stackpane;
    private double OffsetX;
    private double LineWidth;
    public double width;
    private Slider slider;
    private Canvas topCanvas;
    private Stack<Canvas> topLayer;
    private GraphicsContext gc;
    private Stage primaryStage;

    public Sidebar() {
        
        // Establishing a font for the buttons in the sidebar
        // A lot of the code below is mainly for aesthetic purposes
        // We first established all the tools and buttons and made sure they worked before adding colors and fonts
        
        Font font = Font.font("Verdana", FontWeight.BOLD, 12);
        Font font1 = Font.font("Verdana", FontWeight.BOLD, 15);

        OpenButton = new ToggleButton("Add Image");
        // Each button is connected to one of the processes below
        // This is necessary because the buttons won't work if they are not connected to event handlers
        // It's like having a bunch of wires connected to machines, but they don't do anything because they aren't plugged in
        OpenButton.setOnAction(this::processAddImage); 
        OpenButton.setStyle("-fx-background-color: #7c00ff; ");
        OpenButton.setTextFill(Color.WHITE);
        OpenButton.setMaxWidth(120);
        OpenButton.setAlignment(Pos.CENTER);
        OpenButton.setFont(font);
        OpenButton.setCursor(Cursor.HAND);

        undoButton = new Button("Undo Action");
        undoButton.setOnAction(this::processUndo);
        undoButton.setStyle("-fx-background-color: #00d61d; ");
        undoButton.setTextFill(Color.WHITE);
        undoButton.setMaxWidth(120);
        undoButton.setFont(font);
        undoButton.setAlignment(Pos.CENTER);
        // Changes the cursor to a hand symbol to indicate that it is a pressable button for the user
        undoButton.setCursor(Cursor.HAND); 

        layers = new ArrayList<>();

        undoHistory = new Stack<>();

        redoButton = new Button("Redo Action");
        redoButton.setOnAction(this::processRedo);
        redoButton.setStyle("-fx-background-color: #00d61d");
        redoButton.setTextFill(Color.WHITE);
        redoButton.setMaxWidth(120);
        redoButton.setFont(font);
        redoButton.setAlignment(Pos.CENTER);
        redoButton.setCursor(Cursor.HAND);

        addLayer = new Button("Add New Layer");
        addLayer.setOnAction(this::addNewLayer);
        addLayer.setStyle("-fx-background-color: #7c00ff; ");
        addLayer.setTextFill(Color.WHITE);
        addLayer.setMaxWidth(120);
        addLayer.setAlignment(Pos.CENTER);
        addLayer.setFont(font);
        addLayer.setCursor(Cursor.HAND);

        removeLayer = new Button("Remove Layer");
        removeLayer.setOnAction(this::removeTopLayer);
        removeLayer.setStyle("-fx-background-color: #7c00ff; ");
        removeLayer.setTextFill(Color.WHITE);
        removeLayer.setMaxWidth(120);
        removeLayer.setAlignment(Pos.CENTER);
        removeLayer.setFont(font);
        removeLayer.setCursor(Cursor.HAND);

        ClearAll = new ToggleButton("Clear All");
        ClearAll.setStyle("-fx-background-color: #7c00ff; ");
        ClearAll.setTextFill(Color.WHITE);
        ClearAll.setMaxWidth(120);
        ClearAll.setAlignment(Pos.CENTER);
        ClearAll.setFont(font);
        ClearAll.setCursor(Cursor.HAND);
        ClearAll.setOnAction(this::processClear);

        DrawButton = new ToggleButton("Draw");
        DrawButton.setStyle("-fx-background-color: #ff0083; ");

        EraserButton = new ToggleButton("Eraser");
        EraserButton.setStyle("-fx-background-color: #ff0083; ");

        RectangleButton = new ToggleButton("Rectangle");
        RectangleButton.setStyle("-fx-background-color: #ffa600; ");

        CircleButton = new ToggleButton("Circle");
        CircleButton.setStyle("-fx-background-color: #ffa600; ");

        EllipseButton = new ToggleButton("Ellipse");
        EllipseButton.setStyle("-fx-background-color: #ffa600; ");

        LineButton = new ToggleButton("Line");
        LineButton.setStyle("-fx-background-color: #ffa600; ");

        ToggleButton[] ToolSet = {DrawButton, EraserButton, RectangleButton, CircleButton, EllipseButton, LineButton};

        Buttons = new ToggleGroup();

        for (ToggleButton tool : ToolSet) {
            tool.setMinWidth(90);
            tool.setToggleGroup(Buttons);
            tool.setCursor(Cursor.HAND);
            tool.setFont(font);
            tool.setAlignment(Pos.CENTER);
            tool.setTextFill(Color.WHITE);
            tool.setMaxWidth(120);
        }

        Stroke = new ColorPicker(Color.BLACK);
        Fill = new ColorPicker(Color.TRANSPARENT);

        Label StrokeColor = new Label("Stroke Color");
        StrokeColor.setFont(font1);
        StrokeColor.setAlignment(Pos.CENTER);
        StrokeColor.setPrefWidth(150);
        StrokeColor.setWrapText(true);
        StrokeColor.setTextFill(Color.WHITE);

        Label ShapeLabel = new Label("Shapes");
        ShapeLabel.setFont(font1);
        ShapeLabel.setAlignment(Pos.CENTER);
        ShapeLabel.setWrapText(true);
        ShapeLabel.setPrefWidth(150);
        ShapeLabel.setTextFill(Color.WHITE);

        Label FillColor = new Label("Fill Color");
        FillColor.setFont(font1);
        FillColor.setAlignment(Pos.CENTER);
        FillColor.setWrapText(true);
        FillColor.setPrefWidth(150);
        FillColor.setTextFill(Color.WHITE);

        Label Draw = new Label("Brushes");
        Draw.setFont(font1);
        Draw.setAlignment(Pos.CENTER);
        Draw.setWrapText(true);
        Draw.setPrefWidth(150);
        Draw.setTextFill(Color.WHITE);

        Label StrokeWidth = new Label("Line Weight");
        StrokeWidth.setFont(font1);
        StrokeWidth.setPrefWidth(150);
        StrokeWidth.setAlignment(Pos.CENTER);
        StrokeWidth.setWrapText(true);
        StrokeWidth.setTextFill(Color.WHITE);

        slider = new Slider(0, 100, 50);
        width = slider.getValue();
        //sliderLabel.setFont(font);
        slider.setMajorTickUnit(10);
        slider.setMinorTickCount(5);
        slider.setShowTickMarks(true);
        slider.setShowTickLabels(true);
        slider.setValue(0); // sets the initial value of the slider to 0, to be changed later by the user

        Tools = new VBox();
        tools1 = new HBox();
        stackpane = new StackPane();
        Tools.getChildren().addAll(Draw, new Label("\n"), DrawButton, new Label("\n"), EraserButton, new Label("\n"),
                ShapeLabel, new Label("\n"), RectangleButton, new Label("\n"), CircleButton, new Label("\n"),
                EllipseButton, new Label("\n"), LineButton, new Label("\n"), StrokeColor, new Label("\n"), Stroke,
                new Label("\n"), FillColor, new Label("\n"), Fill, new Label("\n" + "\n"), StrokeWidth, new Label("\n"), slider,
                new Label("\n"), undoButton, new Label("\n"), redoButton, new Label("\n"), addLayer, new Label("\n"),
                removeLayer, new Label("\n"), ClearAll, new Label("\n"), OpenButton);

        Tools.setPadding(new Insets(15));
        Tools.setStyle("-fx-background-color: #242D2E");
        Tools.setPrefWidth(170);
        Tools.setAlignment(Pos.CENTER);
        
        setOnMousePressed(this::processMouseClick);
        setOnMouseReleased(this::processShapeDraw);
        setOnMouseDragged(this::processDrawing);

        layers.add(new Stack<Canvas>()); // The layers are in a 'stack' of Canvases, like a bunch of transparent drawing panes
        layers.get(0).push(new Canvas(1300, 900));
        topLayer = layers.get(layers.size() - 1);

        topCanvas = topLayer.peek();
        gc = topCanvas.getGraphicsContext2D();
        gc.setLineWidth(1);
        gc.setFill(Color.WHITE); // The base color is white. We used graphics context here to add elements to the canvas
        gc.fillRect(0, 0, 1300, 900);

        stackpane.getChildren().add(layers.get(0).peek());
        tools1.getChildren().addAll(Tools, stackpane); // The HBox tools1 contains the VBox Tools and the stackpane
        //tools1.getChildren().add(Tools);

        getChildren().add(tools1);
    }

    private class SliderListener implements ChangeListener<Number> {
        
        // This is connected to the slider
        // It gets the value on the slider, and changes the line width of whatever the user is going to draw accordingly

        @Override
        public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {

            gc.setLineWidth(slider.getValue());

        }
    }

    public void processMouseClick(MouseEvent event) {
        
        int layerListSize = layers.size() - 1;
        layers.get(layerListSize).push(new Canvas(1300, 900));
        stackpane.getChildren().add(layers.get(layerListSize).peek());
        topCanvas = layers.get(layerListSize).peek();
        gc = topCanvas.getGraphicsContext2D();
        
        gc.setLineWidth(slider.getValue());
        
        rectangle = new Rectangle();
        circle = new Circle();
        ellipse = new Ellipse();
        line = new Line();
        
        if (RectangleButton.isSelected()) { 
            rectangle.setX(event.getX()); // each time the button is selected, the program kind of 'prepares' to draw a rectangle
            rectangle.setY(event.getY()); // These lines are basically the 'set up' for what the program is about to do 
            gc.setStroke(Stroke.getValue()); // It works like this for every shape
            gc.setFill(Fill.getValue());
        } else if (CircleButton.isSelected()) {
            circle.setCenterX(event.getX());
            circle.setCenterY(event.getY());
            gc.setStroke(Stroke.getValue());
            gc.setFill(Fill.getValue());
        } else if (EllipseButton.isSelected()) {
            ellipse.setCenterX(event.getX());
            ellipse.setCenterY(event.getY());
            gc.setStroke(Stroke.getValue());
            gc.setFill(Fill.getValue());
        } else if (LineButton.isSelected()) {
            line.setStartX(event.getX());
            line.setStartY(event.getY());
            gc.setStroke(Stroke.getValue());
        } else if (DrawButton.isSelected()) {
            gc.beginPath(); // The DrawButton uses a gc.beginPath() to begin drawing the line, sets the current path to empty
            OffsetX = 150;
            // Without the 150 Offset, the mouse would be drawing the shape 150 pixels away from the starting point
            // To fix this issue, we added an OffsetX, altering the display to make it easier for the user
            gc.lineTo(event.getX() - OffsetX, event.getY());
            gc.setStroke(Stroke.getValue()); // The line doesn't have a Fill option because it's just a line
        } else if (EraserButton.isSelected()) {
            gc.beginPath();
            LineWidth = gc.getLineWidth();
            OffsetX = 150;
            gc.lineTo(event.getX() - OffsetX, event.getY());
            gc.setStroke(Color.WHITE);
        }

    }

    public void processShapeDraw(MouseEvent event) { 
        if (RectangleButton.isSelected() && !drag) {
            // This is a Mouse Released event and not a Mouse Dragged event (see setOnAction line 262)
            // This is because as long as you're dragging a shape, rectangled continue to be drawn
            // So instead of one rectangle, you have many overlapping rectangles which don't stop drawing until you release
            // Because of this bug, the display of the rectangle was changed by just making it a mouse released event
            // This doesn't change the logic listed here, just what the user sees
            // This is the logic we used for every shape, it changed with respect to varying parameters
            // But this was the foundation for it
            rectangle.setWidth(Math.abs((event.getX() - rectangle.getX()))); // very similar logic for every shape
            rectangle.setHeight(Math.abs((event.getY() - rectangle.getY()))); // uses this to set width and height of the rectangle

            if (rectangle.getX() > event.getX()) {
                rectangle.setX(event.getX());
            }

            if (rectangle.getY() > event.getY()) {
                rectangle.setY(event.getY());
            }

            gc.fillRect(rectangle.getX() - 150, rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
            gc.strokeRect(rectangle.getX() - 150, rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());

        } else {
            double newX = event.getX();
            double newY = event.getY();

            rectangle.setX(newX);
            rectangle.setY(newY);

            drag = false;
        }

        if (CircleButton.isSelected() && !drag) {
            circle.setRadius((Math.abs(event.getX() - circle.getCenterX()) + Math.abs(event.getY() - circle.getCenterY())) / 2);

            if (circle.getCenterX() > event.getX()) {
                circle.setCenterX(event.getX());
            }
            if (circle.getCenterY() > event.getY()) {
                circle.setCenterY(event.getY());
            }
            // Using the 150 to Offset the X values again, this was done for every shape
            gc.fillOval(circle.getCenterX() - 150, circle.getCenterY(), circle.getRadius(), circle.getRadius());
            gc.strokeOval(circle.getCenterX() - 150, circle.getCenterY(), circle.getRadius(), circle.getRadius());

        } else {
            double newX = event.getX();
            double newY = event.getY();

            circle.setCenterX(newX);
            circle.setCenterY(newY);

            drag = false;
        }

        if (EllipseButton.isSelected() && !drag) {
            ellipse.setRadiusX(Math.abs(event.getX() - ellipse.getCenterX()));
            ellipse.setRadiusY(Math.abs(event.getY() - ellipse.getCenterY()));

            if (ellipse.getCenterX() > event.getX()) {
                ellipse.setCenterX(event.getX());
            }
            if (ellipse.getCenterY() > event.getY()) {
                ellipse.setCenterY(event.getY());
            }

            gc.strokeOval(ellipse.getCenterX() - 150, ellipse.getCenterY(), ellipse.getRadiusX(), ellipse.getRadiusY());
            gc.fillOval(ellipse.getCenterX() - 150, ellipse.getCenterY(), ellipse.getRadiusX(), ellipse.getRadiusY());

        } else {
            double newX = event.getX();
            double newY = event.getY();

            ellipse.setRadiusX(newX);
            ellipse.setRadiusY(newY);

            drag = false;
        }

        if (LineButton.isSelected() && !drag) {
            line.setEndX(event.getX());
            line.setEndY(event.getY());

            gc.strokeLine(line.getStartX() - 150, line.getStartY(), line.getEndX() - 150, line.getEndY());

        } else {
            double newX = event.getX();
            double newY = event.getY();

            line.setEndX(newX);
            line.setEndY(newY);

            drag = false;
        }

    }

    public void processDrawing(MouseEvent event) {
        if (DrawButton.isSelected() && !drag) {
            // gc.lineTo adds segments to the current path to make a line to the given x,y coordinate 
            gc.lineTo(event.getX() - OffsetX, event.getY());
            gc.stroke(); // strokes the path with the current stroke paint

        } else if (EraserButton.isSelected() && !drag) {
            gc.lineTo(event.getX() - OffsetX, event.getY());
            // Originally we were going to use gc.clearRect for this but it wouldn't work no matter what we tried
            // For convenience, we chose to work with a white color to match the background
            gc.setStroke(Color.WHITE); // Color is white because that's the background color
            gc.stroke(); // 

        }

    }

    public void addNewLayer(ActionEvent event) {
        layers.add(new Stack<Canvas>()); // All the layers are in a stack, a new layer is added to it when the button is pressed
        topCanvas = new Canvas(1300, 900);
        layers.get(layers.size() - 1).push(topCanvas);
        stackpane.getChildren().add(topCanvas);
    }

    public void removeTopLayer(ActionEvent event) {
        if (layers.size() > 1) { // A layers is removed from the stack if the size is greater than 1
            topLayer = layers.get(layers.size() - 1);
            while (!topLayer.empty()) {
                stackpane.getChildren().remove(topLayer.pop()); 
            } 
            layers.remove(layers.size() - 1);
        }
    }

    public void processUndo(ActionEvent event) {
        topLayer = layers.get(layers.size() - 1);
        if (!topLayer.empty()) {
            undoHistory.push(topLayer.peek());
            stackpane.getChildren().remove(topLayer.pop());
        }
    }

    public void processRedo(ActionEvent event) {
        if (!undoHistory.empty()) {
            topLayer = layers.get(layers.size() - 1);
            topLayer.push(undoHistory.peek());
            stackpane.getChildren().add(undoHistory.pop());
        }
    }

    public void processClear(ActionEvent event) { // clears everything and starts you off on a blank slate
        
        // This will remove any added layers, and it will also get you back to a white 
        
        topCanvas = topLayer.peek();
        gc = topCanvas.getGraphicsContext2D();
        gc.setLineWidth(1);

        if (ClearAll.isSelected()) {
            gc.setFill(Color.WHITE); 
            gc.fillRect(0, 0, 1300, 900);
        }

        if (layers.size() > 1) {
            topLayer = layers.get(layers.size() - 1);
            while (!topLayer.empty()) {
                stackpane.getChildren().remove(layers.size());
            }
            layers.remove(layers.size());
        }

    }

    public void processAddImage(ActionEvent event) {
        
        // only works for images that are the same size as the window, or smaller
        // really large images will just look like they are zoomed in a lot
        
        if (OpenButton.isSelected()) {

            FileChooser openFile = new FileChooser();
            openFile.setTitle("Open File");
            primaryStage = new Stage();
            File file = openFile.showOpenDialog(primaryStage);
            if (file != null) {
                try {
                    InputStream io = new FileInputStream(file);
                    Image img = new Image(io);
                    gc.drawImage(img, 0, 0);
                } catch (IOException ex) {
                    System.out.println("Error!");
                }
            }
        }
    }
}
