/c/'Program Files'/'NetBeans 8.2'/extide/ant/bin/./ant -f . -Djavafx.main.class=creativespace.CreativeSpace jfxsa-run


## for example:
# /c/'Program Files'/'NetBeans 8.2'/extide/ant/bin/./ant -f C:\\Users\\taylor\\ctis210\\PositionApplicantGUI -Djavafx.main.class=positionapplicantgui.PositionApplicantGUI jfxsa-run