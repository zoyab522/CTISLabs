/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritanceexample;

// for inheritance example guilford college
/**
 *
 * @author zoya
 */
public class CollegeEmployee {

    protected String name;
    protected int Gnumber;
    protected Address address;

    // Constructor sets up this college employee
    // with the specified information
    public CollegeEmployee(String empName, int empGnumber) {

        this.name = empName;
        this.Gnumber = empGnumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGnumber(int Gnumber) {
        this.Gnumber = Gnumber;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public int getGnumber() {
        return Gnumber;
    }

    public Address getAddress() {
        return address;
    }
    
    // print a message appropriate for this employee 
    public void work() {
        System.out.println(name + " works for Guilford College.");
    }

}
