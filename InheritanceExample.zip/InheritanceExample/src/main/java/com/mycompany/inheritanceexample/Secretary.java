/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritanceexample;

/**
 *
 * @author zoya
 */
public class Secretary extends Administrator {

    protected boolean answering;

    // constructor 
    public Secretary(String empN, int empNum, String dept,
            boolean ans) {

        super(empN, empNum, dept);
        answering = ans;

    }

    public void setAnswering(boolean answering) {
        this.answering = answering;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGnumber(int Gnumber) {
        this.Gnumber = Gnumber;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public boolean isAnswering() {
        return answering;
    }

    public String getDepartment() {
        return department;
    }

    public String getName() {
        return name;
    }

    public int getGnumber() {
        return Gnumber;
    }

    public Address getAddress() {
        return address;
    }

    public void answer() {
        System.out.print(name + " is ");
        if (!answering) {
            System.out.print(" not ");
        }
        System.out.print(" answering the phone \n");

    }

    @Override
    public String toString() {
        return super.toString()
                + "Secretary!" + "answering" + answering + ']';

    }
}
