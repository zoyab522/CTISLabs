/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritanceexample;

/**
 *
 * @author zoya
 */
public class Administrator extends CollegeEmployee {

    protected String department;

    public Administrator(String empN, int empNum, String dept) {
        super(empN, empNum);
        this.department = dept;
    }

    public String getDepartment() {
        return department;
    }

    public String getName() {
        return name;
    }

    public int getGnumber() {
        return Gnumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGnumber(int Gnumber) {
        this.Gnumber = Gnumber;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String toString() {
        return super.toString() + " works in " + department;

    }

    // print a message appropriate for this administrator
    public void administrate() {

        System.out.println(
                name + " works in the " + department + " department");
    }

}
