/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.inheritanceexample;

/**
 *
 * @author zoya
 */
public class InheritanceExample_GC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Professor Prof1 = new Professor("Tony", 123, "CompSci");
        Prof1.setSpecialty("Computer Science");
        Prof1.setName("Tony Stark");

        Address add = new Address("58 W Friendly Ave",
                "Greensboro", "NC", "27410");
        Prof1.setAddress(add);

        Prof1.work();
    }

}
