/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritanceexample;

import java.util.Objects;

/**
 *
 * @author zoya
 */
public class Professor extends CollegeEmployee {
    
    protected String specialty;
    
    // constructor to set up this professor with 
    // this specified information
     public Professor (String empN, int empNum, String special) {
         super(empN, empNum);
         this.specialty = special;
         
     }

    public String getSpecialty() {
        return specialty;
    }

    public String getName() {
        return name;
    }

    public int getGnumber() {
        return Gnumber;
    }

    public Address getAddress() {
        return address;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGnumber(int Gnumber) {
        this.Gnumber = Gnumber;
    }

    public void setAddress(Address address) {
        this.address = address;
        
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.specialty);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Professor other = (Professor) obj;
        return Objects.equals(this.specialty, other.specialty);
    }
     
    
     
    
}
