package positionapplicantproject;

public class PositionApplicant {

    private String applicantName = "Nymphadora Tonks";
    private String positionName = "Programmer I";
    private int applicantNumber = 0;
    private double introCompProg = 100;
    private double advCompProg = 94.23;
    private double OperatingSystems = 93.67;
    private double Networking = 97.6;
    private double DataBaseSys = 89.45;
    private double algorithms = 79.32;
    private double overallGPA = 90.45;
    private double averageScore = 83.3;

    public PositionApplicant(String applicantName) {
        this.applicantName = applicantName;
    }

    public PositionApplicant(String applicantName, String positionName, int applicantNumber, double introCompProg,
            double advCompProg, double OperatingSystems, double Networking, double DataBaseSys, double Algorithms, 
            double OverallGPA) {
        this.applicantName = applicantName;
        this.positionName = positionName;
        this.applicantNumber = applicantNumber;
        this.introCompProg = introCompProg;
        this.advCompProg = advCompProg;
        this.OperatingSystems = OperatingSystems;
        this.Networking = Networking;
        this.DataBaseSys = DataBaseSys;
        this.algorithms = Algorithms;
        this.overallGPA = OverallGPA;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;

    }

    public String getpositionName() {
        return positionName;
    }

    public void setpositionName(String positionName) {
        this.positionName = positionName;
    }

    public int getApplicantNumber() {
        return applicantNumber;
    }

    public void setApplicantNumber(int applicantNumber) {
        this.applicantNumber = applicantNumber;
    }

    public double getIntroCompProg() {
        return introCompProg;
    }

    public void setIntroCompProg(double introCompProg) {
        this.introCompProg = introCompProg;
    }

    public double getAdvCompProg() {
        return advCompProg;
    }

    public void setAdvCompProg(double advCompProg) {
        this.advCompProg = advCompProg;
    }

    public double getOperatingSystems() {
        return OperatingSystems;
    }

    public void setOperatingSystems(double OperatingSystems) {
        this.OperatingSystems = OperatingSystems;
    }

    public double getNetworking() {
        return Networking;
    }

    public void setNetworking(double Networking) {
        this.Networking = Networking;
    }

    public double getDataBaseSys() {
        return DataBaseSys;
    }

    public void setDataBaseSys(double DataBaseSys) {
        this.DataBaseSys = DataBaseSys;
    }

    public double getAlgorithms() {
        return algorithms;
    }

    public void setAlgorithms(double Algorithms) {
        this.algorithms = Algorithms;
    }
    
    public double getOverallGPA() {
        return overallGPA;
    }
    
    public void setOverallGPA(double OverallGPA) {
        this.overallGPA = OverallGPA;
    }

    public double calculateAverageScore() {

        double averageScore;
        averageScore = (introCompProg + advCompProg + OperatingSystems + Networking + DataBaseSys + algorithms) / 6;

        return averageScore;

    }

    public double calculateStandardDeviation() {
        double standardDeviation
                = Math.sqrt(((Math.pow(introCompProg, 2.))
                        + (Math.pow(advCompProg, 2.))
                        + (Math.pow(OperatingSystems, 2.))
                        + (Math.pow(Networking, 2.))
                        + (Math.pow(DataBaseSys, 2.))
                        + (Math.pow(algorithms, 2.))) / (6 - 1));
        return standardDeviation;
    }

    public String toString() {
        String output;

        output = "Applicant Name: " + applicantName + "\n"
                + "Position Name: " + positionName + "\n"
                + "Applicant Number: " + applicantNumber + "\n"
                + "Intro to Comp Prog: " + introCompProg + "\n"
                + "Adv Comp Prog: " + advCompProg + "\n"
                + "Operating Systems: " + OperatingSystems + "\n"
                + "Networking: " + Networking + "\n"
                + "Database Systems: " + DataBaseSys + "\n"
                + "Algorithms: " + algorithms + "\n"
                + "Average Score: " + averageScore;

        return output;
    }

    // Consider the applicant further if the score in Introduction to Computer Programming is greater than 80  
    public boolean analyze_applicant1() {
        boolean accept;
        accept = introCompProg > 80;
        return accept;
    }
    
    //Consider the candidate further if both the introCompProg and advCompProg scores are greater than 85  
    public boolean analyze_applicant2() {  
        boolean accept;  
        accept = introCompProg > 85 && advCompProg > 85;  
        return accept;  
    }
    
    /** 
    Consider the candidate further if the overall GPA is greater than 90 or the average score 
    for computing classes is greater than 85 
    **/
    public boolean analyze_applicant3() {
        boolean accept;
        accept = overallGPA > 90 || averageScore > 85;
        return accept;
    }
 
    // * Only consider applicants with a GPA > 83
    // * Don't consider applicants with a grade ≤ 60 in any course
    // * If the applicant has a grade < 76 in Intro to Comp Prog, don’t consider them
    
    public boolean analyze_applicant4() {
        boolean accept;
        accept = overallGPA > 83 && introCompProg > 76 
                && introCompProg > 60 && advCompProg > 60 && OperatingSystems > 60
                && Networking > 60 && DataBaseSys > 60 && algorithms > 60;
        return accept;
    }

    /** 
     * Only consider candidate further if they have a grade ≥ 80 in Algorithms
     * Only consider candidate further if they have a grade ≥ 85 in Advanced Computer Programming
     * Only consider candidate further if they have a grade ≥ 90 in Database Systems
     * Even if the overall GPA is low this criterion prioritizes 3 classes
     * These requirements will consider the more qualified applicants even further with these high grades
     * They will also get rid of applicants who are less skilled or book smart, even if they possess the GPA requirements
    **/
    
    public boolean analyze_applicant5() {
        boolean accept;
        accept = algorithms >= 80 && advCompProg >= 85 && DataBaseSys >= 90;
        return accept;
    }
}
