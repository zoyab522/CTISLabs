/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package positionapplicantproject;

import java.text.DecimalFormat;

/**
 *
 * @author zoya
 */
public class PositionApplicantProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        PositionApplicant theApplicant = new PositionApplicant("Ada Lovelace");
        System.out.println("The applicantName name is " + theApplicant.getApplicantName());

        theApplicant.setApplicantName("Grace Hopper");
        System.out.println("The changed applicant name is " + theApplicant.getApplicantName() + "\n");

        //theApplicant.setApplicantNumber(0);
        //System.out.println("The Applicant Number is: " + theApplicant.getApplicantNumber());
        //theApplicant.setIntroCompProg(100);
        //System.out.println("Intro Comp Prog: " + theApplicant.getIntroCompProg());
        //theApplicant.setAdvCompProg(95);
        //System.out.println("Adv Comp Prog: " + theApplicant.getAdvCompProg());
        //theApplicant.setOperatingSystems(75);
        //System.out.println("Operating Systems: " + theApplicant.getOperatingSystems());
        //theApplicant.setNetworking(80);
        //System.out.println("Networking: " + theApplicant.getNetworking());
        //theApplicant.setDataBaseSys(89);
        //System.out.println("Database Systems: " + theApplicant.getDataBaseSys());
        //theApplicant.setAlgorithms(91);
        //System.out.println("Algorithms: " + theApplicant.getAlgorithms() + "\n");
        //PositionApplicant theOtherApplicant = new PositionApplicant("Nymphadora Tonks",
        //    "Programmer II", 0, 100, 95, 75, 80, 89, 91);
        //System.out.println("Other Applicant Name: " + theOtherApplicant.getApplicantName());
        //System.out.println("Position Name: " + theOtherApplicant.getpositionName());
        //System.out.println("Applicant Number: " + theOtherApplicant.getApplicantNumber());
        //System.out.println("Intro Comp Prog: " + theOtherApplicant.getIntroCompProg());
        //System.out.println("Adv Comp Prog: " + theOtherApplicant.getAdvCompProg());
        //System.out.println("Operating Systems: " + theOtherApplicant.getOperatingSystems());
        //System.out.println("Networking: " + theOtherApplicant.getNetworking());
        //System.out.println("Database Systems: " + theOtherApplicant.getDataBaseSys());
        //System.out.println("Algorithms: " + theOtherApplicant.getAlgorithms() + "\n");
        
        DecimalFormat fmt = new DecimalFormat("##.00");

        System.out.println("The average score in computing classes is "
                + fmt.format(theApplicant.calculateAverageScore()) + "\n");

        //System.out.println(theOtherApplicant.toString());
        System.out.println(theApplicant);

        theApplicant.setApplicantName("Charity Burbage"); //changing attribute for applicant name
        theApplicant.setApplicantNumber(9); //changing attribute for applicant number

        System.out.println("\n" + theApplicant);

        System.out.println("\nStandard Deviation: " + theApplicant.calculateStandardDeviation());
        System.out.println("Standard Deviation: " + fmt.format(theApplicant.calculateStandardDeviation()));

        System.out.println("\nApplicant has a score greater than 80 in Intro Comp Prog and will be considered further : "
                + theApplicant.analyze_applicant1());

        System.out.println("\nThis candidate has scores greater than 85 in Intro Comp Prog and"
                + " Adv Comp Prog and will be considered further: " + theApplicant.analyze_applicant2());

        System.out.println("\nThis candidate has an overall GPA greater than 90 or an average score"
                + " greater than 85 and will be considered further: "
                + theApplicant.analyze_applicant3());

        if (theApplicant.analyze_applicant1()) {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        } else {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Do not consider");
        }

        if (theApplicant.analyze_applicant2()) {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        } else {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        }
        
        if(theApplicant.analyze_applicant3()) {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        } else {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        }
        //prints out “Consider further” when both the analyze_applicant2 and analyze_applicant3 methods return true
        //Otherwise, print out Do not consider 
        if (theApplicant.analyze_applicant2() && theApplicant.analyze_applicant3()) {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        } else {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        }
        
        System.out.println("\nThis candidate has an overall GPA above 83, a grade greater than a 76 "
                + "in Intro to Comp Prog, and grades above 60 in all courses and will be considered further: "
                + theApplicant.analyze_applicant4());
        
        if (theApplicant.analyze_applicant4()) {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Consider further");
        }
        else {
            System.out.println("\n" + theApplicant.getApplicantName() + ": Do not consider");
        }
        
        System.out.println("This candidate has a grade greater than or equal to 80"
                + " in Algorithms and a grade greater than or equal to 85 in Advanced Comp Prog" 
                + " and a grade greater than or equal to 90 in Database Systems and will be evaluated further: "
                + theApplicant.analyze_applicant5());
        
        if (theApplicant.analyze_applicant5()) {
            System.out.println(theApplicant.getApplicantName() + ": Consider further");
        }
        else {
            System.out.println(theApplicant.getApplicantName() + ": Do not consider");
        }
        
    }

}


