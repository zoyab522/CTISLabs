package ctis210exam3eventhandler;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class Exam3EventPane extends Pane {

    private Color currentColor;
    private Color lineColor; // the number that appears as you draw out the line indicates the length of the line
    private Point firstPoint, secondPoint;
    private Line currentLine;
    private ArrayList<Line> ourLines;
    private Button clearButton;
    private double currentLength;
    private Label lengthLabel;
    private boolean exit = false;

    public Exam3EventPane() {
        ourLines = new ArrayList<Line>();

        currentColor = Color.BLACK;
        lineColor = Color.BLACK;

        clearButton = new Button("Clear");
        clearButton.setFocusTraversable(true);
        clearButton.setOnAction(this::processButtonPress);

        getChildren().add(clearButton);

        lengthLabel = new Label("");
        getChildren().add(lengthLabel);

        setOnMousePressed(this::processMousePress);
        setOnMouseDragged(this::processMouseDrag);
        setOnMouseReleased(this::processMouseRelease);
        setOnKeyTyped(this::processKeyPress);
        setOnMouseExited(this::processMouseExit);

    }

    public void processButtonPress(ActionEvent event) {
        for (Line line : ourLines) { // this loops through the array list created called ourLines
            getChildren().remove(line); // as it loops through the array list, it removes all the lines added to the screen
        }
        ourLines.clear();
        firstPoint = null;
        secondPoint = null;
    }

    public void processMousePress(MouseEvent event) {
        firstPoint = new Point(event.getX(), event.getY());
        currentLine = new Line();
        currentLine.setStroke(currentColor);
        getChildren().add(currentLine);
    }

    public void processMouseDrag(MouseEvent event) {
        currentLine.setStartX(firstPoint.getX());
        currentLine.setStartY(firstPoint.getY());
        secondPoint = new Point(event.getX(), event.getY());
        currentLine.setEndX(secondPoint.getX());
        currentLine.setEndY(secondPoint.getY());

        currentLength = firstPoint.distance(secondPoint);
        lengthLabel.setText(String.format("%.2f", currentLength));
        lengthLabel.setLayoutX(secondPoint.getX() + 10);
        lengthLabel.setLayoutY(secondPoint.getY() - 10);

    }

    public void processMouseRelease(MouseEvent event) {
        ourLines.add(currentLine);
        lengthLabel.setText("");
    }

    public void processKeyPress(KeyEvent event) {
//        if (event.getCode() == KeyCode.DIGIT3) { 
//            System.out.println("The number of lines is " + ourLines.size());
//          }  
        // This is logical error because the character 3 is being pressed
        // But the code associated the character with a Key Code
        // You have to write event.getCharacter, not event.getCode for this
        // Also, you need to add a line that says setOnKeyTyped(this::processKeyPress) for this to execute
        if (event.getCharacter().equals("3")) {
            System.out.println("The number of lines is " + ourLines.size());
        }

    }

    public void processMouseExit(MouseEvent event) {
        if (ourLines.size() == 0) {
            firstPoint = null;
            secondPoint = null;
        } else if (!exit) {

            currentLine.setStroke(Color.CYAN);
        }

    }

}
