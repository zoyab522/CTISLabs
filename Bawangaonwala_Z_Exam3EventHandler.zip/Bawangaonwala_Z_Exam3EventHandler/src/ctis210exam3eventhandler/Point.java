package ctis210exam3eventhandler;

public class Point {
    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    
    public double distance(Point otherPoint) {
        double value = Math.pow(x - otherPoint.getX(), 2) + Math.pow(y - otherPoint.getY(), 2);
        value = Math.sqrt(value);
        return value;
    }
    
}
