package recursiveobjects;

import java.util.Random;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class RecursiveObjectPane extends Pane {
    private double initialX = 100;
    private double initialY = 100;
    private double iWidth = 200;
    private double iHeight = 150;
    private double reduceFactor = 0.5;
    private Random rand = new Random();
    
    public RecursiveObjectPane() {
        drawAllRectangles();
        setOnMousePressed(this::processMousePress);
    
}

    private void drawAllRectangles() {
        System.out.println("The number of rectangles is " + 
                addRectangle(initialX, initialY, iWidth, iHeight, reduceFactor));
    }

    private int addRectangle(double x, double y, double width, double height, double reduce) {
        Rectangle theRectangle = new Rectangle(x, y, width, height);
        int red = rand.nextInt(256);
        int green = rand.nextInt(256);
        int blue = rand.nextInt(256);
        double opacity = 0.5 * rand.nextDouble() + 0.3;
        Color newColor = Color.rgb(red, green, blue, opacity);
        theRectangle.setFill(newColor);
        getChildren().add(theRectangle);
        
        reduceFactor = 0.4 * rand.nextDouble() + 0.6;
        double change = 4 * rand.nextDouble();
        double changeX = width * (40 + reduceFactor) * change; 
        double changeY = height * (59 + reduceFactor) * change;
        if (width > 10) { 
            // by reducing the width and height of the rectangle randomly, the recursive function will eventually
            // reach its base case
            // draw two new rectangles in opposite directions
            return addRectangle(x + changeX, y + changeY, width * reduceFactor, height * reduceFactor, reduceFactor)
                    + addRectangle(x - changeX, y - changeY, width * reduceFactor, height * reduceFactor, reduceFactor);
            
        }
        // base case: return the final rectangle and return the value 1
        return 1;
        
    }
    
    public void processMousePress(MouseEvent event) {
        getChildren().clear();
        initialX = event.getX();
        initialY = event.getY();
        iWidth = 55 + rand.nextInt(70);
        iHeight = 55 + rand.nextInt(70);
        drawAllRectangles();
        
    }
        
    
}
