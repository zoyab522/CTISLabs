package ctis210lab6;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.layout.TilePane;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.text.TextAlignment;

public class CTIS210Lab6 extends Application {

    @Override
    public void start(Stage primaryStage) {

        String applicantIndex = "Applicant 0";
        String applicantName = "Charity Burbage";
        double introCompProg = 100;
        double advCompProg = 95;
        double OperatingSystems = 75;
        double Networking = 80;
        double DataBaseSystems = 89;
        double Algorithms = 91;
        double OverallGPA = 83.3;

        TilePane root = new TilePane();

        Image acceptImage = new Image("file:Accept-icon.png");
        ImageView introView = new ImageView(acceptImage);
        introView.setPreserveRatio(true);
        introView.setFitWidth(40);

        ImageView advView = new ImageView(acceptImage);
        advView.setPreserveRatio(true);
        advView.setFitWidth(40);

        ImageView algorithmsView = new ImageView(acceptImage);
        algorithmsView.setPreserveRatio(true);
        algorithmsView.setFitWidth(40);

        Image personImage = new Image("file:person icon.png");
        ImageView personView = new ImageView(personImage);
        personView.setPreserveRatio(true);
        personView.setFitWidth(40);

        ImageView name1 = new ImageView(personImage);
        name1.setPreserveRatio(true);
        name1.setFitWidth(40);

        Image yellowImage = new Image("file:yellow dot.png");
        ImageView networking = new ImageView(yellowImage);
        networking.setPreserveRatio(true);
        networking.setFitWidth(40);

        ImageView databasesys = new ImageView(yellowImage);
        databasesys.setPreserveRatio(true);
        databasesys.setFitWidth(40);

        ImageView GPA = new ImageView(yellowImage);
        GPA.setPreserveRatio(true);
        GPA.setFitWidth(40);

        Image orangeImage = new Image("file:orange dot.png");
        ImageView opsys = new ImageView(orangeImage);
        opsys.setPreserveRatio(true);
        opsys.setFitWidth(40);

        Background labelFill = new Background(new BackgroundFill(Color.PALEGREEN, CornerRadii.EMPTY, Insets.EMPTY));
        Background labelFill2 = new Background(new BackgroundFill(Color.LIGHTPINK, CornerRadii.EMPTY, Insets.EMPTY));
        Background labelFill4 = new Background(new BackgroundFill(Color.PAPAYAWHIP, CornerRadii.EMPTY, Insets.EMPTY));
        Background labelFill3 = new Background(new BackgroundFill(Color.LIGHTYELLOW, CornerRadii.EMPTY, Insets.EMPTY));

        Label nameLabel = new Label("Applicant Index: " + applicantIndex);
        nameLabel.setTextFill(Color.RED);
        Font nameFont = Font.font("Times", FontWeight.BOLD, FontPosture.ITALIC, 20);
        nameLabel.setFont(nameFont);
        nameLabel.setGraphic(personView);
        nameLabel.setContentDisplay(ContentDisplay.LEFT);
        nameLabel.setWrapText(true);
        nameLabel.setMaxWidth(personImage.getWidth() + 250);
        nameLabel.setBackground(labelFill2);

        Label name1Label = new Label("Applicant Name: " + applicantName);
        name1Label.setTextFill(Color.RED);
        name1Label.setFont(nameFont);
        name1Label.setGraphic(name1);
        name1Label.setContentDisplay(ContentDisplay.LEFT);
        name1Label.setWrapText(true);
        name1Label.setMaxWidth(personImage.getWidth() + 250);
        name1Label.setBackground(labelFill2);

        Label introLabel = new Label(" Intro to Comp Prog: " + introCompProg);
        introLabel.setGraphic(introView);
        introLabel.setTextFill(Color.GREEN);
        introLabel.setRotate(0); //set rotation back to zero after testing values
        Font labelFont = Font.font("Montserrat", FontWeight.BOLD, 20);
        introLabel.setFont(labelFont);
        introLabel.setContentDisplay(ContentDisplay.LEFT);
        introLabel.setWrapText(true);
        introLabel.setMaxWidth(acceptImage.getWidth() + 250);
        introLabel.setBackground(labelFill);

        Label advLabel = new Label(" Advanced Comp Prog: " + advCompProg);
        advLabel.setTextFill(Color.GREEN);
        advLabel.setFont(labelFont);
        advLabel.setGraphic(advView);
        advLabel.setContentDisplay(ContentDisplay.LEFT);
        advLabel.setWrapText(true);
        advLabel.setMaxWidth(acceptImage.getWidth() + 250);
        advLabel.setBackground(labelFill);

        Label OpSysLabel = new Label(" Operating Systems: " + OperatingSystems);
        OpSysLabel.setTextFill(Color.ORANGE);
        OpSysLabel.setFont(labelFont);
        OpSysLabel.setGraphic(opsys);
        OpSysLabel.setContentDisplay(ContentDisplay.LEFT);
        OpSysLabel.setWrapText(true);
        OpSysLabel.setMaxWidth(orangeImage.getWidth() + 250);
        OpSysLabel.setBackground(labelFill4);

        Label NetworkingLabel = new Label(" Networking: " + Networking);
        NetworkingLabel.setTextFill(Color.GOLDENROD);
        NetworkingLabel.setFont(labelFont);
        NetworkingLabel.setGraphic(networking);
        NetworkingLabel.setContentDisplay(ContentDisplay.LEFT);
        NetworkingLabel.setWrapText(true);
        NetworkingLabel.setMaxWidth(yellowImage.getWidth() + 250);
        NetworkingLabel.setBackground(labelFill3);

        Label DatabaseSysLabel = new Label(" Database Systems: " + DataBaseSystems);
        DatabaseSysLabel.setTextFill(Color.GOLDENROD);
        DatabaseSysLabel.setFont(labelFont);
        DatabaseSysLabel.setGraphic(databasesys);
        DatabaseSysLabel.setContentDisplay(ContentDisplay.LEFT);
        DatabaseSysLabel.setWrapText(true);
        DatabaseSysLabel.setMaxWidth(yellowImage.getWidth() + 250);
        DatabaseSysLabel.setBackground(labelFill3);

        Label AlgorithmsLabel = new Label(" Algorithms: " + Algorithms);
        AlgorithmsLabel.setTextFill(Color.GREEN);
        AlgorithmsLabel.setFont(labelFont);
        AlgorithmsLabel.setGraphic(algorithmsView);
        AlgorithmsLabel.setContentDisplay(ContentDisplay.LEFT);
        AlgorithmsLabel.setWrapText(true);
        AlgorithmsLabel.setMaxWidth(acceptImage.getWidth() + 250);
        AlgorithmsLabel.setBackground(labelFill);

        Label GPALabel = new Label(" Overall GPA: " + OverallGPA);
        GPALabel.setTextFill(Color.GOLDENROD);
        Font GPAFont = Font.font("Century Gothic", FontWeight.BOLD, 20);
        GPALabel.setFont(GPAFont);
        GPALabel.setGraphic(GPA);
        GPALabel.setContentDisplay(ContentDisplay.LEFT);
        GPALabel.setWrapText(true);
        GPALabel.setMaxWidth(yellowImage.getWidth() + 250);
        GPALabel.setBackground(labelFill3);

        root.getChildren().addAll(nameLabel, name1Label, introLabel, advLabel, OpSysLabel, NetworkingLabel,
                DatabaseSysLabel, AlgorithmsLabel, GPALabel);

        Scene scene = new Scene(root, 339, 366); //changed window size to for better alignment

        primaryStage.setTitle("CTIS 210 Lab 6");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
