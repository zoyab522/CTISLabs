module com.mycompany.tabtest {
    requires javafx.controls;
    exports com.mycompany.tabtest;
}
