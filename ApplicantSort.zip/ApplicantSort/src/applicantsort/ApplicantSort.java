package applicantsort;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ApplicantSort {
        public static void main(String[] args) {

    // TODO code application logic here
    
    ApplicantList theApplicants;
        
    try {
            theApplicants = new ApplicantList(18357);
            // tell the list to sort itself
            theApplicants.sortApplicants();
            
            // print out annotation
            System.out.println("Sort list begins: Applicant Number + GPA");
            
            // loop over the sorted list and print out each Applicant Number and GPA
            for (PositionApplicant applicant : theApplicants.getTheList()) {
                System.out.println(applicant.getApplicantNumber() + "  " + applicant.getOverallGPA());
            }
            
        } catch (Exception ex) {
            Logger.getLogger(ApplicantSort.class.getName()).log(Level.SEVERE, null, ex);
        }

        }
    
}
        

