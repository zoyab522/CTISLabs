package applicantsort;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

public class ApplicantList {

    private PositionApplicant[] theList;

    public ApplicantList(int nApplicants) throws FileNotFoundException {

        theList = new PositionApplicant[nApplicants];

        int iApplicant = 0;

        try {
            Scanner fileScan = new Scanner(new File("allTheApps.txt"));
            Random randGenerator = new Random();
            while (fileScan.hasNext()) {
                double introCompProg = fileScan.nextDouble();
                double advCompProg = fileScan.nextDouble();
                double Networking = fileScan.nextDouble();
                double DataBaseSys = fileScan.nextDouble();
                double algorithms = fileScan.nextDouble();
                double OperatingSystems = fileScan.nextDouble();
                double overallGPA = fileScan.nextDouble();
                int applicantNumber = randGenerator.nextInt(1000000);
                String applicantName = "Nymphadora Tonks";
                String positionName = "Programmer I";
                PositionApplicant theApplicant = new PositionApplicant(applicantName, positionName, applicantNumber,
                        introCompProg, advCompProg, Networking, DataBaseSys, algorithms, OperatingSystems, overallGPA);
                theList[iApplicant] = theApplicant;
                iApplicant = iApplicant + 1;
            }

        } catch (FileNotFoundException e) {
            System.out.println(e);
            System.exit(0);
        }

    }

    public void sortApplicants() {

        mergeSort(theList, theList.length);
    }

    private void mergeSort(PositionApplicant[] all, int n) {
        // Adapted from https://www.baeldung.com/java-merge-sort
        // receives an array and the number of elements to sort
        if (n < 2) {
            // a one-element array is automatically sorted
            //this is the base case
            return;
        }
        // divide the array into two; mid is the number of elements
        // in each half
        int mid = n / 2;

        // allocate and fill the two halves from the original array
        // Build two arrays, one to hold each half
        PositionApplicant[] left = new PositionApplicant[mid];
        PositionApplicant[] right = new PositionApplicant[n - mid];

        // actually divide the array in half in a left and right side
        // put the first half of the all array into left
        for (int i = 0; i < mid; i = i + 1) {
            left[i] = all[i];
        }
        // put the second half of the all array into right
        for (int i = mid; i < n; i = i + 1) {
            right[i - mid] = all[i];
        }
        // Once we've done this, we have two smaller problems

        // Solve each of the two smaller problems
        // call mergeSort to sort each of the two halves
        mergeSort(left, mid);
        mergeSort(right, n - mid);
        // only after some of the mergeSort calls start returning 
        // do we merge the results
        merge(all, left, right, mid, n - mid);
    }

    private void merge
        (PositionApplicant[] all, PositionApplicant[] left, PositionApplicant[] right, int leftIndex, int rightIndex) {

        int i = 0, j = 0, k = 0;
        while (i < leftIndex && j < rightIndex) {
            // decide whether the current top element of the 
            // left or right arrays has the smaller value
            if (left[i].getOverallGPA()
                    >= right[j].getOverallGPA()) {

                all[k] = left[i];
                i = i + 1;
            } else {
                all[k] = right[j];
                j = j + 1;
            }
            k = k + 1;
        }
        while (i < leftIndex) {
            all[k] = left[i];
            i = i + 1;
            k = k + 1;
        }
        while (j < rightIndex) {
            all[k] = right[j];
            k = k + 1;
            j = j + 1;
        }
    }

    public PositionApplicant[] getTheList() {
        return theList;
    }

}
