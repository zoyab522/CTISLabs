package applicantevaluation;

import java.util.Random;


public class PositionApplicant {
    
    private double introCompProg;
    private double advCompProg;
    private double networking;
    private double databaseSystems;
    private double algorithms;
    private double operatingSystems;
    private double overallGPA;

    public PositionApplicant(double introToCS, double advCompProg, double networking, double databaseSystems, double algorithms, double operatingSystems, double overallGPA) {
        this.introCompProg = introToCS;
        this.advCompProg = advCompProg;
        this.networking = networking;
        this.databaseSystems = databaseSystems;
        this.algorithms = algorithms;
        this.operatingSystems = operatingSystems;
        this.overallGPA = overallGPA;
    }
    
    public PositionApplicant() {
        
    }
    

    public double getIntroCompProg() {
        return introCompProg;
    }

    public void setIntroCompProg(int introCompProg) {
        this.introCompProg = introCompProg;
    }

    public double getAdvCompProg() {
        return advCompProg;
    }

    public void setAdvCompProg(int advCompProg) {
        this.advCompProg = advCompProg;
    }

    public double getNetworking() {
        return networking;
    }

    public void setNetworking(int softwareEngineering) {
        this.networking = softwareEngineering;
    }

    public double getDatabaseSystems() {
        return databaseSystems;
    }

    public void setDatabaseSystems(int databaseSystems) {
        this.databaseSystems = databaseSystems;
    }

    public double getAlgorithms() {
        return algorithms;
    }

    public void setAlgorithms(int algorithms) {
        this.algorithms = algorithms;
    }

    public double getOperatingSystems() {
        return operatingSystems;
    }

    public void setOperatingSystems(int operatingSystems) {
        this.operatingSystems = operatingSystems;
    }

    public double getOverallGPA() {
        return overallGPA;
    }

    public void setOverallGPA(double overallGPA) {
        this.overallGPA = overallGPA;
    }

    @Override
    public String toString() {
        return "Applicant{" + "introCompProg=" + introCompProg + ", advCompProg=" + advCompProg + ", networking=" + networking + ", algorithms=" + algorithms + ", databaseSystems=" + databaseSystems + ", operatingSystems=" + operatingSystems + ", overallGPA=" + overallGPA + '}';
    }
    
   public boolean approve_applicant1() {
        boolean accept = true;

        if (overallGPA < 80) {
            accept = false;
        }

        return accept;
    }


    
    
}
