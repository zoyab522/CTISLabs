package applicantevaluation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ApplicantEvaluation {

    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<PositionApplicant> applicants = new ArrayList<PositionApplicant>();

        // Read applicant information
        try {
            Scanner fileScan = new Scanner(new File("allTheNewApps.txt"));
            while (fileScan.hasNext()) {
                //  System.out.println(fileScan.next());

                double introToCompProg = fileScan.nextDouble();
                double advCompProg = fileScan.nextDouble();
                double networking = fileScan.nextDouble();
                double databaseSystems = fileScan.nextDouble();
                double algorithms = fileScan.nextDouble();
                double operatingSystems = fileScan.nextDouble();
                double overallGPA = fileScan.nextDouble();
                PositionApplicant theApplicant = new PositionApplicant(introToCompProg, advCompProg, networking, databaseSystems, algorithms, operatingSystems, overallGPA);
                applicants.add(theApplicant);
            }
            System.out.println("The size of the list is " + applicants.size());

            fileScan.close();
        } catch (FileNotFoundException e) {
            System.out.println(e);
            System.exit(0);
        }

// Add code for Lab 15 after this line
        PositionApplicant theApplicant = applicants.get(0);
        System.out.println("Applicant 0 is " + theApplicant);

        PositionApplicant anotherApplicant = applicants.get(1);
        System.out.println("Applicant 1 is " + anotherApplicant);

        PositionApplicant OneMoreApplicant = applicants.get(2);
        System.out.println("Applicant 2 is " + OneMoreApplicant);

        int[] introHistogram = new int[5];
        for (PositionApplicant applicant : applicants) {

            double value = applicant.getIntroCompProg();
            int index;
            if (value < 20) {
                index = 0;
            } else if (value < 40) {
                index = 1;
            } else if (value < 60) {
                index = 2;
            } else if (value < 80) {
                index = 3;
            } else {
                index = 4;
            }

            introHistogram[index] = introHistogram[index] + 1;

        }

        System.out.println("The introCompProg histogram is " + Arrays.toString(introHistogram));

        // while loop to calculate sum of the values in the bins
        int index = 0;
        int sum = 0;
        while (index < introHistogram.length) {

            sum = sum + introHistogram[index];
            index = index + 1;

        }

        int BinsSum = sum;
        System.out.println("The sum of the values in all the bins is " + BinsSum);

        int[] advHistogram = new int[5];
        for (PositionApplicant applicant : applicants) {

            double value = applicant.getAdvCompProg();
            int index1;
            if (value < 20) {
                index1 = 0;
            } else if (value < 40) {
                index1 = 1;
            } else if (value < 60) {
                index1 = 2;
            } else if (value < 80) {
                index1 = 3;
            } else {
                index1 = 4;
            }

            advHistogram[index1] = advHistogram[index1] + 1;

        }

        while (index < advHistogram.length) {

            sum = sum + advHistogram[index];
            index = index + 1;

        }

        System.out.println("The advCompProg histogram is " + Arrays.toString(advHistogram));
        System.out.println("The sum of the values in all the bins is " + sum);

        //System.out.println(introHistogram[-1]); OutOfBoundsException error (runtime error)
        //System.out.println(introHistogram[5]); OutOfBoundsException error (runtime error)
        int[] introHistogram20 = new int[20];

        for (PositionApplicant applicant : applicants) {
            double value = applicant.getIntroCompProg();
            index = (int) ((value) / 5);
            introHistogram20[index] = introHistogram20[index] + 1;
        }

        System.out.println("introHistogram20: " + Arrays.toString(introHistogram20));

        int index3 = 0;
        int sum3 = 0;

        while (index3 < introHistogram20.length) {

            sum3 = sum3 + introHistogram20[index3];
            index3 = index3 + 1;

        }

        System.out.println("The sum of the values in all the bins is " + sum3); // checking the sum using the while loop

        // Applying the methods to a second score: Algorithms
        int[] algorithmsHistogram = new int[25];

        for (PositionApplicant applicant : applicants) {
            double value = applicant.getAlgorithms();
            index = (int) ((value) / 4);
            algorithmsHistogram[index] = algorithmsHistogram[index] + 1;
        }

        System.out.println("algorithmsHistogram: " + Arrays.toString(algorithmsHistogram));

        int index4 = 0;
        int sum4 = 0;

        while (index4 < algorithmsHistogram.length) {
            sum4 = sum4 + algorithmsHistogram[index4];
            index4 = index4 + 1;

        }

        System.out.println("The sum of the values in all the bins is " + sum4);

    }

}
