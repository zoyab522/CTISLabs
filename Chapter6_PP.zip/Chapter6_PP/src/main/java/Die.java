/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author zoya
 * Die.java
 * Die class represents one die (singular of dice) with faces showing values ranging from 1 and the max number
 * of faces;
 */
public class Die {
    
    private final int MAX = 6; // max face values
    
    private int faceValue; // current value showing on the die
    
    public Die() // Constructor
    {
        faceValue = 1;
    }
    
    public int roll()
    {
        faceValue = (int) (Math.random() * MAX + 1);
        return faceValue;
    }

    public void setFaceValue(int faceValue) {
        this.faceValue = faceValue;
    }

    public int getMAX() {
        return MAX;
    }

    public int getFaceValue() {
        return faceValue;
    }

    @Override
    public String toString() {
        return "Die{" + "MAX=" + MAX + ", faceValue=" + faceValue + '}';
    }
}
