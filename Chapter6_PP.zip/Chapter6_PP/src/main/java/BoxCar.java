/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 * @author zoya
 * Programming Project 6.5
 * Roll a pair of dice 1000 times
 * count the number of box cars (two sixes)
 */
public class BoxCar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        final int ROLLS = 1000, TARGET = 12;
        int total, count2 = 0,
                count3 = 0,
                count4 = 0,
                count5 = 0,
                count6 = 0,
                count7 = 0,
                count8 = 0,
                count9 = 0,
                count10 = 0,
                count11 = 0,
                count12 = 0;

        PairOfDice dice = new PairOfDice();

        for (int roll = 1; roll <= ROLLS; roll++) {
            total = dice.roll();
            switch (total) {
                case 2:
                    count2++; break;
                case 3:
                    count3++; break;
                case 4:
                    count4++; break;
                case 5:
                    count5++; break;
                case 6:
                    count6++; break;
                case 7:
                    count7++; break;
                case 8:
                    count8++; break;
                case 9:
                    count9++; break;
                case 10:
                    count10++; break;
                case 11:
                    count11++; break;
                case 12:
                    count12++; break;
                default: System.out.println("Incorrect sum");

            }
        }

        System.out.println("Number of rolls: " + ROLLS
                + "\nSum = 2: " + count2 
                + "\nSum = 3: " + count3 
                + "\nSum = 4: " + count4 
                + "\nSum = 5: " + count5 
                + "\nSum = 6: " + count6 
                + "\nSum = 7: " + count7
                + "\nSum = 8: " + count8
                + "\nSum = 9: " + count9
                + "\nSum = 10: " + count10
                + "\nSum = 11: " + count11
                + "\nSum = 12: " + count12);

    }

}
