/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author zoya
 */
public class PairOfDice {

    private Die die1, die2;

    public PairOfDice() { // constructor to create 2 6-sided die objects
        // both with initial face values equal to 1
        die1 = new Die();
        die2 = new Die();
    }

    public int roll() { // rolls both dice and returns the combined result
        return die1.roll() + die2.roll();
    }

    public int getTotalFaceValue() {
        return die1.getFaceValue() + die2.getFaceValue();
    }

    public int getDie1FaceValue() {
        return die1.getFaceValue();
    }

    public int getDie2FaceValue() {
        return die2.getFaceValue();
    }

    public String toString() {
        return "Die1: " + die1.getFaceValue()
                + "\tDie2: " + die2.getFaceValue();
    }

}
